CREATE TYPE             "DBMS_XPLAN_TYPE"                                          
  as object (plan_table_output varchar2(300));
/
