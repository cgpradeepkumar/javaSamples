CREATE TYPE             "DBMS_XPLAN_TYPE_TABLE"                                          
  as table of dbms_xplan_type;
/
