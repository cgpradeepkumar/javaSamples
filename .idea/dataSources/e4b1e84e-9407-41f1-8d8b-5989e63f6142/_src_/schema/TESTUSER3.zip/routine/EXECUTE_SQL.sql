CREATE FUNCTION execute_sql( sql_stmt in varchar2 ) 
  RETURN VARCHAR2 
IS 
BEGIN
      BEGIN
        --EXECUTE IMMEDIATE sql_stmt;
        DBMS_OUTPUT.put_line ('done'||sql_stmt);
      EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error code ' || SQLCODE || ': ' || SQLERRM || ':' || SUBSTR(sql_stmt,0,20));
      END;
END;
/
