CREATE FUNCTION cs_execute(to_execute IN varchar2)
RETURN number IS
   total number := 0;
BEGIN

    BEGIN
   

     EXECUTE IMMEDIATE to_execute;

    EXCEPTION    
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Error code ' || SQLCODE || ': ' || SQLERRM);
      ROLLBACK;
    END;

END;
/
