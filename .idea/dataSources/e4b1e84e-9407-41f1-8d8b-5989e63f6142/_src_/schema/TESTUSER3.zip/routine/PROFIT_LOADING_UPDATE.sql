CREATE PROCEDURE profit_loading_update (prm_sub_type IN NUMBER, prm_double_value IN NUMBER, prm_benefit_id IN NUMBER) AS
BEGIN	
	UPDATE Q_LOOKUP_BEN_SINGLE_VALUE SET DOUBLE_VALUE=prm_double_value WHERE BENEFIT_ID=prm_benefit_id AND SUB_TYPE_ID=prm_sub_type AND TYPE_ID=160
;IF SQL%ROWCOUNT = 0 THEN
	INSERT INTO Q_LOOKUP_BEN_SINGLE_VALUE (BENEFIT_ID,TYPE_ID,SUB_TYPE_ID,DOUBLE_VALUE,STRING_VALUE,USER_ID,TIMESTAMP) VALUES (prm_benefit_id,160,prm_sub_type,prm_double_value,null,9999,SYSDATE)
;END IF
;END profit_loading_update
;
/
