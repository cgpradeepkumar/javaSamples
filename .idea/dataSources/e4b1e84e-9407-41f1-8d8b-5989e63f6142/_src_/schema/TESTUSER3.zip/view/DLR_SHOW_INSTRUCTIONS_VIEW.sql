CREATE VIEW DLR_SHOW_INSTRUCTIONS_VIEW AS SELECT r.name conno,
          p.name grpno,
          p.description,
          inv.external_reference porno,
          inv.id inv_id,
          v.VALUE_NAME,
          i.EFFECTIVE_DATE,
          ui.EXTERNAL_REFERENCE import_ref,
          i.id instruction_id,
          i.state,
          ui.unit_instruction_type,
          h.id holding_id,
          inv.id investment_id,
          uihd.amount_quantity,
          uihd.inxn_denomination
     FROM dlr_instruction i,
          dlr_unit_instruction ui,
          dlr_unit_inxn_holding_detail uihd,
          dlr_holding h,
          dlr_investment inv,
          dlr_value v,
          dlr_portfolio p,
          dlr_role r
    WHERE     i.id = ui.id
          AND uihd.instruction_id = i.id
          AND h.id = uihd.holding_id
          AND inv.id = h.value_id
          AND v.id = inv.id
          AND i.state != 'Sent'
          AND r.id = p.role_id
          AND p.id = h.portfolio_id
/
