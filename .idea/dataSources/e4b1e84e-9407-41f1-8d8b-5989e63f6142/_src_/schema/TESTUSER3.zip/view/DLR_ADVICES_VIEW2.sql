CREATE VIEW DLR_ADVICES_VIEW2 AS SELECT isup.EXTERNAL_REFERENCE account,
          h.EXTERNAL_REFERENCE sub_account,
          ui.UNIT_INSTRUCTION_TYPE,
          CASE alloc.DENOMINATION_ID
             WHEN 3 THEN ROUND (alloc.currency_quantity, 2)
             ELSE ROUND (uihd.AMOUNT_QUANTITY, 6)
          END
             amount,
          DECODE (alloc.DENOMINATION_ID, 3, 'Rand', 'Unit') advice_type,
          uihd.DIRECTION,
          v.VALUE_NAME investment_name,
          ps.STRATEGY_NAME,
          i.effective_date trade_date,
          i.state advice_state,
          ai.id instruction_id,
          contra.id txn_ref_id,
          ai.document_reference,
          CASE cd.CONTACT_DETAIL_TYPE
             WHEN 'TRANSFER' THEN td.TRANSFER_STRATEGY
             WHEN 'FAX' THEN fd.FAX_NUMBER
             ELSE 'UNKNOWN'
          END
             advice_detail,
          ui.unit_instruction_type instruction_type,
          inv_owner.name owner_name,
          inv_owner.description owner_description,
          inv.external_reference porno,
          inv.id investment_id,
          h.id supplier_holding_id,
          alloc_h.ID trader_holding_id
     FROM dlr_advice_instruction ai,
          dlr_instruction i,
          dlr_unit_instruction ui,
          dlr_unit_inxn_holding_detail uihd,
          dlr_holding_contact_details hcd,
          dlr_holding alloc_h,
          DLR_INVESTMENT_TDR_PORTFOLIO tdr_p,
          DLR_PRODUCT_STRATEGY ps,
          dlr_contact_detail cd,
          dlr_fax_detail fd,
          DLR_TRANSFER_DETAIL td,
          dlr_investment inv,
          dlr_value v,
          dlr_holding h,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_dlr_transaction contra,
          dlr_role inv_owner,
          DLR_INVESTMENT_SUP_PORTFOLIO isup
    WHERE     i.id = ai.id
          AND ui.id = i.id
          AND inv.id = v.id
          AND h.id = uihd.holding_id
          AND v.id = h.value_id
          AND inv_owner.id = inv.investment_supplier_id
          AND uihd.instruction_id = i.id
          AND hcd.holding_id = uihd.holding_id
          AND cd.id = hcd.contact_detail_id
          AND cd.purpose =
                 DECODE (ui.unit_instruction_type,
                         'AdviceSell', 'DISINVESTMENTS',
                         'AdviceBuy', 'INVESTMENTS',
                         'SWITCHES')
          AND fd.id(+) = cd.id
          AND td.id(+) = cd.id
          AND h.PORTFOLIO_ID = isup.id
          AND alloc.HOLDING_ID = alloc_h.ID
          AND tdr_p.id = alloc_h.PORTFOLIO_ID
          AND ps.id = tdr_p.PRODUCT_STRATEGY_ID
          AND ptxn.id = ai.txn_reference
          AND alloc.parent_transaction_id = ptxn.id
          AND contra.parent_transaction_id = alloc.id
   UNION
   SELECT isup.EXTERNAL_REFERENCE account,
          h.EXTERNAL_REFERENCE sub_account,
          ui.UNIT_INSTRUCTION_TYPE,
          CASE alloc.DENOMINATION_ID
             WHEN 3 THEN ROUND (alloc.currency_quantity, 2)
             ELSE ROUND (uihd.AMOUNT_QUANTITY, 6)
          END
             amount,
          DECODE (alloc.DENOMINATION_ID, 3, 'Rand', 'Unit') advice_type,
          uihd.DIRECTION,
          v.VALUE_NAME investment_name,
          ps.STRATEGY_NAME,
          i.effective_date trade_date,
          i.state advice_state,
          ai.id instruction_id,
          contra.id txn_ref_id,
          ai.document_reference,
          CASE cd.CONTACT_DETAIL_TYPE
             WHEN 'TRANSFER' THEN td.TRANSFER_STRATEGY
             WHEN 'FAX' THEN fd.FAX_NUMBER
             ELSE 'UNKNOWN'
          END
             advice_detail,
          ui.unit_instruction_type instruction_type,
          inv_owner.name owner_name,
          inv_owner.description owner_description,
          inv.external_reference porno,
          inv.id investment_id,
          h.id supplier_holding_id,
          alloc_h.ID trader_holding_id
     FROM dlr_advice_instruction ai,
          dlr_instruction i,
          dlr_unit_instruction ui,
          dlr_unit_inxn_holding_detail uihd,
          dlr_holding_contact_details hcd,
          dlr_holding alloc_h,
          DLR_INVESTMENT_TDR_PORTFOLIO tdr_p,
          DLR_PRODUCT_STRATEGY ps,
          dlr_contact_detail cd,
          dlr_fax_detail fd,
          DLR_TRANSFER_DETAIL td,
          dlr_investment inv,
          dlr_value v,
          dlr_holding h,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction btxn,
          dlr_dlr_transaction alloc,
          dlr_dlr_transaction contra,
          dlr_role inv_owner,
          DLR_INVESTMENT_SUP_PORTFOLIO isup
    WHERE     i.id = ai.id
          AND ui.id = i.id
          AND inv.id = v.id
          AND h.id = uihd.holding_id
          AND v.id = h.value_id
          AND inv_owner.id = inv.investment_supplier_id
          AND uihd.instruction_id = i.id
          AND hcd.holding_id = uihd.holding_id
          AND cd.id = hcd.contact_detail_id
          AND cd.purpose =
                 DECODE (ui.unit_instruction_type,
                         'AdviceSell', 'DISINVESTMENTS',
                         'AdviceBuy', 'INVESTMENTS',
                         'SWITCHES')
          AND fd.id(+) = cd.id
          AND td.id(+) = cd.id
          AND h.PORTFOLIO_ID = isup.id
          AND alloc.HOLDING_ID = alloc_h.ID
          AND tdr_p.id = alloc_h.PORTFOLIO_ID
          AND ps.id = tdr_p.PRODUCT_STRATEGY_ID
          AND ptxn.id = ai.txn_reference
          AND btxn.PARENT_TRANSACTION_ID = ptxn.id
          AND alloc.parent_transaction_id = btxn.id
          AND contra.parent_transaction_id = alloc.id
          AND btxn.DEFINITION LIKE '%SwitchSell%'
/
