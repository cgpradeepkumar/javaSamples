CREATE VIEW DLR_VIEW_INVESTMENT_TRADERS AS SELECT trader.ID investment_trader_id,
          trader.NAME investment_trader_name,
          dlr_product.ID product_id,
          dlr_product.NAME product_name,
          dlr_product_strategy.ID prod_strategy_id,
          dlr_product_strategy.STRATEGY_NAME prod_strategy_name,
          dlr_portfolio.ID portfolio_id,
          dlr_portfolio.NAME portfolio_name,
          dlr_holding.ID holding_id,
          ROUND (dlr_holding.unit_quantity, 6) rub,
          dlr_holding.HOLDING_NAME,
          supplier.ID investment_supplier_id,
          supplier.NAME investment_supplier_orbit_name,
          supplier.DESCRIPTION investment_supplier_name,
          dlr_investment.ID investment_id,
          dlr_value.VALUE_NAME investment_name,
          dlr_investment.EXTERNAL_REFERENCE investment_orbit_name
     FROM dlr_holding,
          dlr_portfolio,
          dlr_investment_tdr_portfolio,
          dlr_product_strategy,
          dlr_product,
          dlr_role trader,
          dlr_role supplier,
          dlr_value,
          dlr_investment
    WHERE     dlr_investment.ID = dlr_holding.VALUE_ID
          AND dlr_value.ID = dlr_investment.ID
          AND supplier.ID = dlr_investment.INVESTMENT_SUPPLIER_ID
          AND dlr_investment_tdr_portfolio.ID = dlr_holding.PORTFOLIO_ID
          AND dlr_portfolio.ID = dlr_investment_tdr_portfolio.ID
          AND dlr_product_strategy.ID =
                 dlr_investment_tdr_portfolio.PRODUCT_STRATEGY_ID
          AND dlr_product.ID = dlr_product_strategy.PRODUCT_ID
          AND trader.ID = dlr_portfolio.ROLE_ID
/
