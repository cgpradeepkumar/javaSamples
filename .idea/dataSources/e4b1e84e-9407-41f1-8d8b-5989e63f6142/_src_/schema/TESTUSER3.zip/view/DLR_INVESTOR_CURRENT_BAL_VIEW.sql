CREATE VIEW DLR_INVESTOR_CURRENT_BAL_VIEW AS SELECT r.id,
          r.name conno,
          p.id portfolio_id,
          p.name grpno,
          h.id holding_id,
          inv.id investment_id,
          inv.external_reference porno,
          v.value_name,
          ps.strategy_name,
          ROUND (h.unit_quantity, 6) unit_balance
     FROM dlr_holding h,
          dlr_investment inv,
          dlr_portfolio p,
          dlr_investor_portfolio ip,
          dlr_role r,
          dlr_value v,
          dlr_product_strategy ps
    WHERE     inv.id = h.value_id
          AND p.id = h.portfolio_id
          AND p.role_id = r.id
          AND v.id = inv.id
          AND ip.id = p.id
          AND ps.id = ip.product_strategy_id
/
