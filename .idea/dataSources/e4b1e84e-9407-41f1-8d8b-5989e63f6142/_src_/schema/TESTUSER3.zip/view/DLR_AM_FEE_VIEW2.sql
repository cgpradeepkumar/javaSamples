CREATE VIEW DLR_AM_FEE_VIEW2 AS SELECT r.name conno,
          p.name grpno,
          inv.EXTERNAL_REFERENCE porno,
          alloc.INVESTMENT_ID,
          alloc.HOLDING_ID alloc_holding_id,
          contra.holding_id trader_holding,
          ptxn.id,
          ptxn.DEFINITION,
          ptxn.STATE name,
          ptxn.EFFECTIVE_DATE,
          ROUND (alloc.currency_quantity, 2) rands,
          ROUND (alloc.unit_quantity2, 6) units,
          alloc.DENOMINATION_ID
     FROM DLR_DLR_TRANSACTION ptxn,
          DLR_DLR_TRANSACTION alloc,
          dlr_dlr_transaction contra,
          dlr_holding h,
          dlr_portfolio p,
          dlr_role r,
          dlr_holding ch,
          DLR_INVESTMENT inv
    WHERE     alloc.PARENT_TRANSACTION_ID = ptxn.id
          AND contra.PARENT_TRANSACTION_ID = alloc.id
          AND inv.id = alloc.INVESTMENT_ID
          AND h.id = alloc.HOLDING_ID
          AND p.id = h.PORTFOLIO_ID
          AND r.id = p.ROLE_ID
          AND ch.id = contra.HOLDING_ID
          AND ptxn.DEFINITION LIKE '%Fee%'
/
