CREATE VIEW BB_BROKER_NEXT AS SELECT ROWNUM AS num,
            code,
            broker_house_code,
            channel_id
       FROM bb_broker
   ORDER BY num
/
