CREATE VIEW VW_SYNC_IN_USER AS SELECT N."USER_ID",
          N."USER_GROUP_CDE",
          N."NAME",
          N."SURNAME",
          N."EMAIL",
          N."DIAL_CODE",
          N."TEL_NO"
     FROM MTD_USER N
          INNER JOIN MTAX_SUBMITTER_DETAILS O ON N.USER_ID = O.CRMID
/
