CREATE VIEW DLR_SUPPLIER_TRADER_CUST_VIEW AS SELECT r.name supplier_name,
            r.description,
            r.id role_id,
            p.name account_name,
            h.id supplier_holding_id,
            rel.to_id trader_holding,
            supp.ID spid,
            inv.id investment_id,
            inv.external_reference porno,
            v.value_name,
            inv.INVESTMENT_TYPE,
            h.external_reference subAccount,
            supp.external_reference accountName,
            p.id portfolio_id,
            p.description p_description,
            supp.external_reference,
            ps.id product_strategy_id,
            ps.STRATEGY_NAME product_strategy_name,
            ROUND (h.unit_quantity, 6) supplier_balance,
            ROUND (th.unit_quantity, 6) trader_balance,
            ROUND (customers.cust_sum_units, 6) sum_customer_balance,
            ROUND (
               (h.unit_quantity + th.unit_quantity + customers.cust_sum_units),
               6)
               s_t_c
       FROM dlr_holding h
            JOIN dlr_investment inv ON (inv.id = h.VALUE_ID)
            JOIN dlr_portfolio p ON (p.id = h.PORTFOLIO_ID)
            JOIN dlr_investment_sup_portfolio supp ON (supp.id = p.id)
            JOIN dlr_role r ON (p.role_id = r.id)
            JOIN dlr_value v ON (v.id = inv.id)
            JOIN dlr_holding th ON (th.VALUE_ID = inv.id)
            JOIN dlr_relationship rel
               ON (    rel.from_id = h.id
                   AND th.id = rel.to_id
                   AND rel.TYPE = 'Trader Holding')
            JOIN dlr_investment_tdr_portfolio tp ON (th.portfolio_id = tp.id)
            JOIN dlr_product_strategy ps ON (ps.id = tp.product_strategy_id)
            LEFT JOIN
            (  SELECT inv.id investment_id,
                      ps.id product_strat_id,
                      inv.EXTERNAL_REFERENCE porno,
                      SUM (h.UNIT_QUANTITY) cust_sum_units
                 FROM dlr_holding h,
                      dlr_investment inv,
                      dlr_portfolio p,
                      dlr_investor_portfolio ip,
                      dlr_role r,
                      dlr_value v,
                      dlr_product_strategy ps
                WHERE     inv.id = h.value_id
                      AND p.id = h.portfolio_id
                      AND p.role_id = r.id
                      AND v.id = inv.id
                      AND ip.id = p.id
                      AND ps.id = ip.product_strategy_id
             GROUP BY inv.id, ps.id, inv.EXTERNAL_REFERENCE) customers
               ON (    customers.product_strat_id = ps.id
                   AND customers.investment_id = inv.ID)
   ORDER BY ABS (
               (h.unit_quantity + th.unit_quantity + customers.cust_sum_units))
/
