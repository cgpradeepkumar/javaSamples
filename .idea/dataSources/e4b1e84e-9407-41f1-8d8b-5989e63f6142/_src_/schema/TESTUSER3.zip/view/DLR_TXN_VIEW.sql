CREATE VIEW DLR_TXN_VIEW AS SELECT
effective_date,definition,processed_date,txn_id,holding_id,balance,rands,units,'0.0' longUnits,'0.0' shortUnits,denom denomination FROM DLR_TXN_VIEW2
/
