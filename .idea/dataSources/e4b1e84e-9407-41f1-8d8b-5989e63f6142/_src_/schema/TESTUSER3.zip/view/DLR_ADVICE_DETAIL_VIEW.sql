CREATE VIEW DLR_ADVICE_DETAIL_VIEW AS SELECT ptxn.definition,
          i.effective_date fax_date,
          ai.id instruction_id,
          ai.document_reference,
          contra.id supplier_txn_ref,
          fd.fax_number,
          ui.unit_instruction_type instruction_type,
          uihd.direction,
          uihd.inxn_denomination denom,
          ROUND (uihd.AMOUNT_QUANTITY, 6) units,
          inv.id investment_id,
          inv.external_reference porno,
          v.value_name,
          ROUND (alloc.currency_quantity, 2) rands,
          inv_owner.name owner_name,
          inv_owner.description owner_description
     FROM dlr_advice_instruction ai,
          dlr_instruction i,
          dlr_unit_instruction ui,
          dlr_unit_inxn_holding_detail uihd,
          dlr_holding_contact_details hcd,
          dlr_contact_detail cd,
          dlr_fax_detail fd,
          dlr_investment inv,
          dlr_value v,
          dlr_holding h,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_dlr_transaction contra,
          dlr_role inv_owner
    WHERE     i.id = ai.id
          AND ui.id = i.id
          AND inv.id = v.id
          AND h.id = uihd.holding_id
          AND v.id = h.value_id
          AND inv_owner.id = inv.investment_supplier_id
          AND uihd.instruction_id = i.id
          AND hcd.holding_id = uihd.holding_id
          AND cd.id = hcd.contact_detail_id
          AND cd.purpose =
                 DECODE (ui.unit_instruction_type,
                         'Sell', 'DISINVESTMENTS',
                         'Buy', 'INVESTMENTS',
                         'SWITCHES')
          AND fd.id = cd.id
          AND ptxn.id = ai.txn_reference
          AND alloc.parent_transaction_id = ptxn.id
          AND contra.parent_transaction_id = alloc.id
   UNION
   SELECT ptxn.definition,
          i.effective_date fax_date,
          ai.id instruction_id,
          ai.document_reference,
          contra.id supplier_txn_ref,
          fd.fax_number,
          ui.unit_instruction_type instruction_type,
          uihd.direction,
          uihd.inxn_denomination denom,
          ROUND (uihd.AMOUNT_QUANTITY, 6) units,
          inv.id investment_id,
          inv.external_reference porno,
          v.value_name,
          ROUND (alloc.currency_quantity, 2) rands,
          inv_owner.name owner_name,
          inv_owner.description owner_description
     FROM dlr_advice_instruction ai,
          dlr_instruction i,
          dlr_unit_instruction ui,
          dlr_unit_inxn_holding_detail uihd,
          dlr_holding_contact_details hcd,
          dlr_contact_detail cd,
          dlr_fax_detail fd,
          dlr_investment inv,
          dlr_value v,
          dlr_holding h,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_dlr_transaction contra,
          dlr_dlr_transaction btxn,
          dlr_role inv_owner
    WHERE     i.id = ai.id
          AND ui.id = i.id
          AND btxn.parent_transaction_id = ptxn.id
          AND ptxn.parent_transaction_id IS NULL
          AND btxn.definition LIKE '%Buy'
          AND inv.id = v.id
          AND h.id = uihd.holding_id
          AND v.id = h.value_id
          AND inv_owner.id = inv.investment_supplier_id
          AND uihd.instruction_id = i.id
          AND hcd.holding_id = uihd.holding_id
          AND cd.id = hcd.contact_detail_id
          AND cd.purpose =
                 DECODE (ui.unit_instruction_type,
                         'Sell', 'DISINVESTMENTS',
                         'Buy', 'INVESTMENTS',
                         'SWITCHES')
          AND fd.id = cd.id
          AND ptxn.id = ai.txn_reference
          AND alloc.parent_transaction_id = btxn.id
          AND contra.parent_transaction_id = alloc.id
/
