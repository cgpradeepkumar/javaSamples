CREATE VIEW DLR_TXN_VIEW2 AS SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
alloc.definition definition,
alloc.processed_date processed_date,
alloc.id txn_id,
alloc.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
round(alloc.resultant_unit_quantity,6) balance,
DECODE ( alloc.direction,'-',- 1 * alloc.currency_quantity,alloc.currency_quantity ) rands,
DECODE ( alloc.direction,'-',- 1 * alloc.unit_quantity2,alloc.unit_quantity2 ) units,
alloc.denomination_id denom FROM dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = ptxn.id
AND ( ptxn.state = 'Finalised' or ptxn.state ='Reversed&Replaced' )
AND alloc.definition LIKE '%Allocation'
and alloc.RESULTANT_UNIT_QUANTITY is not null
AND h.id = alloc.holding_id
AND inv.id = h.value_id
UNION
SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
contra.definition definition,
alloc.processed_date processed_date,
contra.id txn_id,
contra.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
round(contra.resultant_unit_quantity,6) balance,
DECODE ( contra.direction,'-',- 1 * alloc.currency_quantity,alloc.currency_quantity ) rands,
DECODE ( contra.direction,'-',- 1 * alloc.unit_quantity2,alloc.unit_quantity2 ) units,
alloc.denomination_id denom FROM dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
dlr_dlr_transaction contra,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = ptxn.id
AND contra.parent_transaction_id = alloc.id
AND ( ptxn.state = 'Finalised' or ptxn.state ='Reversed&Replaced' )
AND h.id = contra.holding_id
AND inv.id = h.value_id
AND contra.definition LIKE '%Contra'
and contra.RESULTANT_UNIT_QUANTITY is not null
UNION
SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
alloc.definition definition,
alloc.processed_date processed_date,
alloc.id txn_id,
alloc.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
round(alloc.resultant_unit_quantity,6) balance,
DECODE ( alloc.direction,'-',- 1 * alloc.currency_quantity,alloc.currency_quantity ) rands,
DECODE ( alloc.direction,'-',- 1 * alloc.unit_quantity2,alloc.unit_quantity2 ) units,
alloc.denomination_id denom FROM dlr_dlr_transaction pptxn,
dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
dlr_dlr_transaction contra,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = pptxn.id
AND pptxn.parent_transaction_id = ptxn.id
AND contra.parent_transaction_id = alloc.id
AND ( ptxn.state = 'Finalised' or ptxn.state ='Reversed&Replaced' )
AND alloc.definition LIKE '%Allocation'
and alloc.RESULTANT_UNIT_QUANTITY is not null
AND h.id = alloc.holding_id
AND inv.id = h.value_id
UNION
SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
contra.definition definition,
alloc.processed_date processed_date,
contra.id txn_id,
contra.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
round(contra.resultant_unit_quantity,6) balance,
DECODE ( contra.direction,'-',- 1 * alloc.currency_quantity,alloc.currency_quantity ) rands,
DECODE ( contra.direction,'-',- 1 * alloc.unit_quantity2,alloc.unit_quantity2 ) units,
alloc.denomination_id denom FROM dlr_dlr_transaction ptxn,
dlr_dlr_transaction pptxn,
dlr_dlr_transaction alloc,
dlr_dlr_transaction contra,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = pptxn.id
AND contra.parent_transaction_id = alloc.id
AND pptxn.parent_transaction_id = ptxn.id
AND ( ptxn.state = 'Finalised' or ptxn.state ='Reversed&Replaced' )
AND h.id = contra.holding_id
AND inv.id = h.value_id
AND contra.definition LIKE '%Contra'
and contra.RESULTANT_UNIT_QUANTITY is not null
ORDER BY processed_date,txn_id
/
