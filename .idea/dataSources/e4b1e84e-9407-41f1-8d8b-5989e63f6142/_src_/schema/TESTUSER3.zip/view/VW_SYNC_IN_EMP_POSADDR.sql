CREATE VIEW VW_SYNC_IN_EMP_POSADDR AS SELECT N.*
     FROM (SELECT *
             FROM MTD_ADDRESS A
                  INNER JOIN MTD_DIRECTIVE_REQUEST R
                     ON A.ADDRESS_ID = R.EMP_POST_ADDRESS_ID) N
          INNER JOIN
          (SELECT A.*, D.*, AT.*
             FROM (SELECT *
                     FROM MTAX_EMPLOYER_ADDRESS
                    WHERE    LINE_ONE_DETAILS IS NOT NULL
                          OR LINE_TWO_DETAILS IS NOT NULL
                          OR LINE_THREE_DETAILS IS NOT NULL
                          OR LINE_FOUR_DETAILS IS NOT NULL) A
                  INNER JOIN MTAX_DIRECTIVE D ON A.EMPLOYER = D.REFERENCE_KEY
                  INNER JOIN MTAX_ADDRESS_TYPE AT ON A.TYPE = AT.ID
            WHERE A.TYPE = 1) O
             ON N.REQ_SEQ_NUM = O.REFERENCE_KEY
/
