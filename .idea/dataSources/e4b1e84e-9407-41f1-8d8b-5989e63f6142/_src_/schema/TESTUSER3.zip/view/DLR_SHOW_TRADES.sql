CREATE VIEW DLR_SHOW_TRADES AS SELECT ptxn.EXTERNAL_REFERENCE tradeno,
          ptxn.id txn_id,
          r.NAME conno,
          p.NAME grpno,
          inv.EXTERNAL_REFERENCE porno,
          alloc.INVESTMENT_ID,
          state.name txn_state,
          ier.STATE price_state,
          state.id state_id,
          ptxn.EFFECTIVE_DATE,
          alloc.PROCESSED_DATE,
          ptxn.DEFINITION,
          alloc.HOLDING_ID alloc_h,
          contra.HOLDING_ID contra_h,
          alloc.currency_quantity customer_rands,
          DECODE (alloc.DIRECTION,
                  '-', -1 * alloc.unit_quantity2,
                  alloc.unit_quantity2)
             alloc_units,
          alloc.DENOMINATION_ID
     FROM DLR_DLR_TRANSACTION ptxn,
          DLR_DLR_TRANSACTION alloc,
          dlr_dlr_transaction contra,
          DLR_INVESTMENT inv,
          dlr_role r,
          dlr_portfolio p,
          dlr_holding h,
          dlr_transaction_state state,
          DLR_INVESTMENT_EXCHANGE_RATE ier
    WHERE     alloc.PARENT_TRANSACTION_ID = ptxn.id
          AND inv.id = alloc.INVESTMENT_ID
          AND h.PORTFOLIO_ID = p.id
          AND r.id = p.ROLE_ID
          AND h.id = alloc.HOLDING_ID
          AND ier.id = alloc.PRICE
          AND state.id = ptxn.TRANSACTION_STATE
          AND alloc.DEFINITION LIKE '%Allocation'
          AND alloc.id > ptxn.id
          AND contra.id > ptxn.id
          AND ptxn.id > 5000000
          AND contra.PARENT_TRANSACTION_ID = alloc.id
/
