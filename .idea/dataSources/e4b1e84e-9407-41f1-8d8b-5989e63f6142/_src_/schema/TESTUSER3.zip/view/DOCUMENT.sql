CREATE VIEW DOCUMENT AS SELECT DOC_ID,
          FILENAME,
          MIME_TYPE,
          DESCRIPTION,
          DOC_CLASS,
          DOC_TYPE,
          BUS_UNIT,
          IS_ACTIVE_VERSION,
          DATE_TIME_CREATED,
          CREATED_BY,
          DATE_TIME_MODIFIED,
          MODIFIED_BY,
          POLICY_ID,
          DATA,
          TOWER_IFN,
          WF_CASE_REF,
          LEASED_MINUTES,
          ACCESS_KEY
     FROM DM_DOCUMENT
   WITH CHECK OPTION
/
