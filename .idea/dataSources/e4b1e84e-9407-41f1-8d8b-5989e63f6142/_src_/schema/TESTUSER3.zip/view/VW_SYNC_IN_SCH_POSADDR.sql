CREATE VIEW VW_SYNC_IN_SCH_POSADDR AS SELECT N."ADDRESS_ID",
          N."ADDRESS1",
          N."ADDRESS2",
          N."ADDRESS3",
          N."ADDRESS4",
          N."ADDRESS5",
          N."ADDRESS6",
          N."CODE",
          N."ADDRESS_FORMAT_CDE",
          N."FUND_ID",
          N."FUND_GROUP_ID",
          N."FUND_TYPE_CDE",
          N."FUND_CREATE_REASON_CDE",
          N."FUND_POST_ADDRESS_ID",
          N."CONTRACT_NUMBER",
          N."FUND_NUMBER",
          N."FUND_NAME",
          N."FUND_DIAL_CODE",
          N."FUND_TEL_NO",
          N."FUND_CONTACT_PERSON",
          N."PRIVATE",
          N."ORBIT",
          N."ACTIVE"
     FROM (SELECT *
             FROM MTD_ADDRESS A
                  INNER JOIN MTD_FUND F
                     ON A.ADDRESS_ID = F.FUND_POST_ADDRESS_ID) N
          INNER JOIN
          (SELECT A.*, S.*
             FROM MTAX_SCHEME_ADDRESS A
                  INNER JOIN MTAX_SCHEME S ON A.SCHEME = S.ID
                  INNER JOIN MTAX_ADDRESS_TYPE AT ON A.TYPE = AT.ID
            WHERE A.TYPE = 1) O
             ON N.CONTRACT_NUMBER = O.ID
/
