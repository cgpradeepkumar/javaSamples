CREATE VIEW DLR_SHOW_LEKANA_SETUP AS SELECT party.name conno,
          p.name grpno,
          p.id portfolio_ID,
          ps.STRATEGY_NAME,
          tp.NAME trader_portfolio,
          th.id trader_holding,
          sh.id supplier_holding,
          v.VALUE_NAME investment_name,
          inv.EXTERNAL_REFERENCE porno,
          sh.EXTERNAL_REFERENCE subaccount,
          sp.EXTERNAL_REFERENCE bulkaccount,
          facs.TXN_TYPE_SELL,
          facs.TXN_TYPE_BUY
     FROM DLR_PARTY party,
          DLR_PORTFOLIO p,
          DLR_INVESTOR_PORTFOLIO ip,
          DLR_PRODUCT_STRATEGY ps,
          dlr_role r,
          DLR_INVESTMENT_TDR_PORTFOLIO itp,
          dlr_portfolio tp,
          DLR_INVESTMENT_SUP_PORTFOLIO sp,
          dlr_holding th,
          DLR_RELATIONSHIP rel,
          dlr_holding sh,
          dlr_value v,
          DLR_INVESTMENT inv,
          dlr_facs facs
    WHERE     r.id = p.ROLE_ID
          AND p.ROLE_ID = party.Id
          AND ip.id = p.id
          AND ps.id = ip.PRODUCT_STRATEGY_ID
          AND sh.PORTFOLIO_ID = sp.ID
          AND itp.PRODUCT_STRATEGY_ID = ps.id
          AND tp.id = itp.id
          AND th.PORTFOLIO_ID = tp.ID
          AND rel.FROM_ID = th.id
          AND rel.TYPE = 'Supplier Holding'
          AND sh.id = rel.TO_ID
          AND v.id = sh.VALUE_ID
          AND inv.id = v.id
          AND facs.conno = r.name
/
