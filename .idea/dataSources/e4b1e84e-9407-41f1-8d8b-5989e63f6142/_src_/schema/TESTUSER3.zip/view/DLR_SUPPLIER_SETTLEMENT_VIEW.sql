CREATE VIEW DLR_SUPPLIER_SETTLEMENT_VIEW AS SELECT
i.id settlement_id,
i.id ref_on_bank,
contra.id dlr_txn_ref,
i.effective_date,
ROUND (si.TOTAL_AMOUNT_QUANTITY,2) si_amount_total,
ROUND (si.TOTAL_AMOUNT_QUANTITY,2) se_amount_total,
ROUND (si.TOTAL_AMOUNT_QUANTITY,2) bank_amount_total,
ROUND (alloc.CURRENCY_QUANTITY,2) unit_txn_rand_amount,
si.us_settle_party_id,
null definition,
payer.account_number payer_account_number,
payee.account_number payee_account_number,
party.description them_description,
alloc.definition unit_txn_definition,
alloc.id unit_txn_id,
alloc.holding_id unit_txn_holding_id,
alloc.denomination_id,
payee.reference
FROM dlr_settlement_instruction si,
dlr_instruction i,
DLR_SETTLEMENT_PARTY_DETAIL payee,
DLR_SETTLEMENT_PARTY_DETAIL payer,
dlr_dlr_transaction contra,
dlr_dlr_transaction alloc,
dlr_dlr_transaction ptxn,
dlr_investment inv,
dlr_holding h,
dlr_portfolio p,
dlr_role r,
dlr_party party,
DLR_INVESTMENT_SUP_PORTFOLIO isup
WHERE i.id = si.id
and h.id=contra.HOLDING_ID
and p.id=h.PORTFOLIO_ID
and r.id=p.ROLE_ID
and party.id=r.PARTY_ID
and isup.id=p.id
AND payer.id = si.PAYER_ID
AND payee.id = si.PAYEE_ID
AND contra.settlement_id = si.id
AND alloc.id = contra.parent_transaction_id
AND ptxn.id = alloc.parent_transaction_id
AND inv.id = alloc.investment_id
/
