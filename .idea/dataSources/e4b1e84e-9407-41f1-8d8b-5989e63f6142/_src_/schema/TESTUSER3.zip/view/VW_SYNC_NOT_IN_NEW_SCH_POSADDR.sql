CREATE VIEW VW_SYNC_NOT_IN_NEW_SCH_POSADDR AS SELECT O."TYPE",
          O."SCHEME",
          O."LINE_ONE_DETAILS",
          O."LINE_TWO_DETAILS",
          O."LINE_THREE_DETAILS",
          O."LINE_FOUR_DETAILS",
          O."CODE",
          O."ID",
          O."FUND_NAME",
          O."PRODUCT_TYPE",
          O."CREATE_REASON",
          O."APPROVAL_NUMBER",
          O."PAYE_NUMBER",
          O."PRIVATE",
          O."ORBIT_CONTRACT",
          O."ACTIVE",
          O."ACTIVE_REASON"
     FROM (SELECT A.*, S.*
             FROM MTAX_SCHEME_ADDRESS A
                  INNER JOIN MTAX_SCHEME S ON A.SCHEME = S.ID
                  INNER JOIN MTAX_ADDRESS_TYPE AT ON A.TYPE = AT.ID
            WHERE A.TYPE = 1) O
          LEFT JOIN
          (SELECT *
             FROM MTD_ADDRESS A
                  INNER JOIN MTD_FUND F
                     ON A.ADDRESS_ID = F.FUND_POST_ADDRESS_ID) N
             ON N.CONTRACT_NUMBER = O.ID
    WHERE N.CONTRACT_NUMBER IS NULL
/
