CREATE VIEW SM_EXTSYSPROP_PAGER_BACKWARD AS SELECT extsysprop_id, extsys_id, displayName
       FROM sm_extsysprop
   ORDER BY extsysprop_id DESC
/
