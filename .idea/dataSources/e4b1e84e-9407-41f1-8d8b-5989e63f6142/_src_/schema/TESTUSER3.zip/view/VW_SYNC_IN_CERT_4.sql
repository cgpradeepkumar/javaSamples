CREATE VIEW VW_SYNC_IN_CERT_4 AS SELECT N."CERTIFICATE_NUMBER", N."EMPLOYEE_NUMBER", N."IDENTITY_NUMBER"
     FROM (SELECT TO_NUMBER (CERTIFICATE_NUMBER) AS CERTIFICATE_NUMBER,
                  EMPLOYEE_NUMBER,
                  IDENTITY_NUMBER
             FROM MTD_CERTIFICATE
            WHERE CERTIFICATE_TYPE_CDE = 4) N
          INNER JOIN
          (  SELECT CERTIFICATENUMBER,
                    MEMBERNUMBER,
                    CASE
                       WHEN (   IDENTIFICATIONNUMBER IS NULL
                             OR LENGTH (IDENTIFICATIONNUMBER) <> 13)
                       THEN
                          NULL
                       ELSE
                          IDENTIFICATIONNUMBER
                    END
                       AS IDENTIFICATIONNUMBER
               FROM MTAX_IT3A
              WHERE CONTRACTNUMBER NOT IN ('999', '1122')
           GROUP BY CERTIFICATENUMBER, MEMBERNUMBER, IDENTIFICATIONNUMBER) O
             ON     NVL (O.CERTIFICATENUMBER, 0) =
                       NVL (N.CERTIFICATE_NUMBER, 0)
                AND NVL (O.MEMBERNUMBER, ' ') = NVL (N.EMPLOYEE_NUMBER, ' ')
                AND NVL (O.IDENTIFICATIONNUMBER, ' ') =
                       NVL (N.IDENTITY_NUMBER, ' ')
/
