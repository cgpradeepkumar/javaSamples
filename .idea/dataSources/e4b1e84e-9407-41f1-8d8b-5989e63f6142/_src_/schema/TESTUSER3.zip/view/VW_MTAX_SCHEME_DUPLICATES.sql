CREATE VIEW VW_MTAX_SCHEME_DUPLICATES AS SELECT S."ID",S."FUND_NAME",S."PRODUCT_TYPE",S."CREATE_REASON",S."APPROVAL_NUMBER",S."PAYE_NUMBER",S."PRIVATE",S."ORBIT_CONTRACT",S."ACTIVE",S."ACTIVE_REASON"
     FROM MTAX_SCHEME S
          INNER JOIN (  SELECT MIN (ID) AS MIN_ID,
                               MAX (ID) AS MAX_ID,
                               UPPER (FUND_NAME) AS FUND_NAME,
                               PRODUCT_TYPE,
                               CREATE_REASON,
                               APPROVAL_NUMBER,
                               PAYE_NUMBER,
                               PRIVATE,
                               ORBIT_CONTRACT,
                               ACTIVE,
                               ACTIVE_REASON,
                               COUNT (*)
                          FROM MTAX_SCHEME
                      GROUP BY UPPER (FUND_NAME),
                               PRODUCT_TYPE,
                               CREATE_REASON,
                               APPROVAL_NUMBER,
                               PAYE_NUMBER,
                               PRIVATE,
                               ORBIT_CONTRACT,
                               ACTIVE,
                               ACTIVE_REASON
                        HAVING COUNT (*) > 1) DUP
             ON     UPPER (S.FUND_NAME) = UPPER (DUP.FUND_NAME)
                AND S.APPROVAL_NUMBER = DUP.APPROVAL_NUMBER
                AND S.PRODUCT_TYPE = DUP.PRODUCT_TYPE
                AND S.CREATE_REASON = DUP.CREATE_REASON
                AND S.PAYE_NUMBER = DUP.PAYE_NUMBER
                AND S.PRIVATE = DUP.PRIVATE
                AND S.ORBIT_CONTRACT = DUP.ORBIT_CONTRACT
                AND S.ACTIVE = DUP.ACTIVE
                AND S.ACTIVE_REASON = DUP.ACTIVE_REASON
/
