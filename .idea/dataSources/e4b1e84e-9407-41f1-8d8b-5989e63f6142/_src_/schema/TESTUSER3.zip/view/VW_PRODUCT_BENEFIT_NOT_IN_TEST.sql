CREATE VIEW VW_PRODUCT_BENEFIT_NOT_IN_TEST AS SELECT "PRODUCT_ID",
          "BENEFIT_ID",
          "LOOKUP_TYPE",
          "ID",
          "TYPE_NAME",
          "ID_NAME",
          "FORMAT_TYPE",
          "PRODUCT_DESCRIPTION",
          "EXTERNAL_VALUE",
          "SEQUENCE_NO",
          "ACTIVE_INDICATOR",
          "TYPE",
          "SUB_TYPE",
          "BENEFIT_DESCRIPTION",
          "APPROVAL_TYPE",
          "CAN_BE_BUNDLED"
     FROM VW_PRODUCT_BENEFIT
    WHERE (PRODUCT_ID, BENEFIT_ID) IN (SELECT PRODUCT_ID, BENEFIT_ID
                                         FROM VW_PRODUCT_BENEFIT
                                       MINUS
                                       SELECT PRODUCT_ID, BENEFIT_ID
                                         FROM VW_PRODUCT_BENEFIT_IN_TEST
                                       MINUS
                                       SELECT PRODUCT_ID, BENEFIT_ID
                                         FROM VW_PRODUCT_BENEFIT_NOT_USED
                                       MINUS
                                       SELECT PRODUCT_ID, BENEFIT_ID
                                         FROM VW_PRODUCT_BENEFIT_MIGRATION)
/
