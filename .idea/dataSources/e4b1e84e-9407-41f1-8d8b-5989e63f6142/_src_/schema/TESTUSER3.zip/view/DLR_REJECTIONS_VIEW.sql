CREATE VIEW DLR_REJECTIONS_VIEW AS SELECT ptxn.external_reference,
          ptxn.id ptxn_id,
          alloc.currency_quantity rands,
          alloc.unit_quantity2 units,
          h.unit_quantity avaliable_units,
          h.unit_quantity - alloc.unit_quantity2 diff,
          ptxn.effective_date,
          ptxn.definition,
          ier.state price_state,
          ier.effective_date price_date,
          alloc.processed_date,
          alloc.investment_id,
          v.value_name,
          inv.external_reference porno,
          alloc.denomination_id,
          ptxn.state txn_state,
          r.name conno,
          p.name grpno,
          h.id holding_id
     FROM dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_investment_exchange_rate ier,
          dlr_investment inv,
          dlr_value v,
          dlr_dlr_transaction contra,
          dlr_holding h,
          dlr_portfolio p,
          dlr_role r
    WHERE     ptxn.state = 'Rejected'
          AND alloc.parent_transaction_id = ptxn.id
          AND ptxn.parent_transaction_id IS NULL
          AND h.id = alloc.holding_id
          AND p.id = h.portfolio_id
          AND r.id = p.role_id
          AND ier.id = alloc.price
          AND inv.id = alloc.investment_id
          AND v.id = inv.id
          AND contra.parent_transaction_id = alloc.id
   UNION
   SELECT ptxn.external_reference,
          ptxn.id ptxn_id,
          alloc.currency_quantity rands,
          alloc.unit_quantity2 units,
          h.unit_quantity avaliable_units,
          h.unit_quantity - alloc.unit_quantity2 diff,
          ptxn.effective_date,
          ptxn.definition,
          ier.state price_state,
          ier.effective_date price_date,
          alloc.processed_date,
          alloc.investment_id,
          v.value_name,
          inv.external_reference porno,
          alloc.denomination_id,
          ptxn.state txn_state,
          r.name conno,
          p.name grpno,
          h.id holding_id
     FROM dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_investment_exchange_rate ier,
          dlr_investment inv,
          dlr_value v,
          dlr_dlr_transaction contra,
          dlr_holding h,
          dlr_portfolio p,
          DLR_DLR_TRANSACTION btxn,
          dlr_role r
    WHERE     ptxn.state = 'Rejected'
          AND alloc.PARENT_TRANSACTION_ID = btxn.id
          AND btxn.PARENT_TRANSACTION_ID = ptxn.id
          AND ptxn.parent_transaction_id IS NULL
          AND h.id = alloc.holding_id
          AND p.id = h.portfolio_id
          AND r.id = p.role_id
          AND ier.id = alloc.price
          AND inv.id = alloc.investment_id
          AND v.id = inv.id
          AND contra.parent_transaction_id = alloc.id
/
