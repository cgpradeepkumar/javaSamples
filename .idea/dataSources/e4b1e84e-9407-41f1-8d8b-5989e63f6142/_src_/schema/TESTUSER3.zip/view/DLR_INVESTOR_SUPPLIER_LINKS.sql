CREATE VIEW DLR_INVESTOR_SUPPLIER_LINKS AS SELECT r.name conno,
          p.NAME grpno,
          p.DESCRIPTION group_description,
          inv.EXTERNAL_REFERENCE porno,
          inv.id investment_id,
          v.VALUE_NAME investment_name,
          ps.STRATEGY_NAME,
          supp.EXTERNAL_REFERENCE AM_account,
          sh.EXTERNAL_REFERENCE am_sub_acount,
          sh.ID supplier_holding_id,
          th.ID trader_holding_id,
          h.id customer_holding_id
     FROM dlr_portfolio p,
          dlr_role r,
          DLR_INVESTMENT inv,
          DLR_VALUE v,
          DLR_PRODUCT_STRATEGY ps,
          DLR_HOLDING th,
          DLR_INVESTMENT_TDR_PORTFOLIO tp,
          dlr_holding sh,
          DLR_PORTFOLIO sp,
          DLR_RELATIONSHIP rel,
          DLR_INVESTMENT_SUP_PORTFOLIO supp,
          dlr_holding h,
          DLR_INVESTOR_PORTFOLIO ip
    WHERE     v.id = inv.ID
          AND h.VALUE_ID = inv.ID
          AND ip.id = p.id
          AND p.id = h.PORTFOLIO_ID
          AND ip.PRODUCT_STRATEGY_ID = ps.id
          AND th.VALUE_ID = inv.id
          AND r.id = p.ROLE_ID
          AND ps.id = tp.PRODUCT_STRATEGY_ID
          AND th.PORTFOLIO_ID = tp.id
          AND tp.PRODUCT_STRATEGY_ID = ps.id
          AND th.VALUE_ID = inv.id
          AND rel.FROM_ID = th.id
          AND rel.TO_ID = sh.ID
          AND sp.id = sh.PORTFOLIO_ID
          AND rel.TYPE = 'Supplier Holding'
          AND supp.id = sp.ID
/
