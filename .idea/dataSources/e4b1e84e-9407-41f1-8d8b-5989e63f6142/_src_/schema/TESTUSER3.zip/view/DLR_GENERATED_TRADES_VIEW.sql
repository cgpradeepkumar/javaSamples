CREATE VIEW DLR_GENERATED_TRADES_VIEW AS SELECT ptxn.EFFECTIVE_DATE trade_date,
          alloc.id trader_alloc_id,
          cust_alloc.id customer_alloc_id,
          alloc.DEFINITION trader_def,
          cust_alloc.DEFINITION cust_def,
          ROUND (alloc.CURRENCY_QUANTITY, 2) trader_rands,
          ROUND (cust_alloc.CURRENCY_QUANTITY, 2) cust_rands,
          ROUND (alloc.UNIT_QUANTITY2, 6) trader_units,
          ROUND (cust_alloc.UNIT_QUANTITY2, 6) cust_units,
          alloc.DENOMINATION_ID trader_denom,
          cust_alloc.DENOMINATION_ID cust_denom,
          inv.id investment_id,
          inv.EXTERNAL_REFERENCE porno,
          v.VALUE_NAME,
          isup.EXTERNAL_REFERENCE supplier_account,
          sh.EXTERNAL_REFERENCE supplier_sub_account
     FROM DLR_DLR_TRANSACTION ptxn,
          dlr_dlr_transaction alloc,
          dlr_instruction trader_inxn,
          dlr_instruction trader_uinxn,
          DLR_RELATIONSHIP rel,
          dlr_dlr_transaction cust_alloc,
          dlr_investment inv,
          dlr_dlr_transaction contra,
          DLR_INVESTMENT_SUP_PORTFOLIO isup,
          dlr_holding sh,
          dlr_value v
    WHERE     trader_inxn.id = trader_uinxn.ID
          AND ptxn.EXTERNAL_REFERENCE = trader_inxn.ID
          AND trader_inxn.EFFECTIVE_DATE = ptxn.EFFECTIVE_DATE
          AND rel.TYPE = 'trade'
          AND cust_alloc.id = rel.TO_ID
          AND rel.FROM_ID = trader_inxn.id
          AND alloc.PARENT_TRANSACTION_ID = ptxn.id
          AND contra.PARENT_TRANSACTION_ID = alloc.id
          AND isup.id = sh.PORTFOLIO_ID
          AND sh.id = contra.HOLDING_ID
          AND v.id = inv.id
          AND inv.id = alloc.INVESTMENT_ID
   UNION
   SELECT ptxn.EFFECTIVE_DATE trade_date,
          alloc.id trader_alloc_id,
          cust_alloc.id customer_alloc_id,
          alloc.DEFINITION trader_def,
          cust_alloc.DEFINITION cust_def,
          ROUND (alloc.CURRENCY_QUANTITY, 2) trader_rands,
          ROUND (cust_alloc.CURRENCY_QUANTITY, 2) cust_rands,
          ROUND (alloc.UNIT_QUANTITY2, 6) trader_units,
          ROUND (cust_alloc.UNIT_QUANTITY2, 6) cust_units,
          alloc.DENOMINATION_ID trader_denom,
          cust_alloc.DENOMINATION_ID cust_denom,
          inv.id investment_id,
          inv.EXTERNAL_REFERENCE porno,
          v.VALUE_NAME,
          isup.EXTERNAL_REFERENCE supplier_account,
          sh.EXTERNAL_REFERENCE supplier_sub_account
     FROM DLR_RELATIONSHIP rel,
          dlr_dlr_transaction cust_alloc,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_dlr_transaction btxn,
          dlr_investment inv,
          dlr_dlr_transaction contra,
          DLR_INVESTMENT_SUP_PORTFOLIO isup,
          dlr_holding sh,
          dlr_value v
    WHERE     rel.TYPE = 'TradedBy'
          AND cust_alloc.ID = rel.FROM_ID
          AND inv.id = alloc.INVESTMENT_ID
          AND v.id = inv.id
          AND contra.PARENT_TRANSACTION_ID = alloc.id
          AND isup.id = sh.PORTFOLIO_ID
          AND sh.id = contra.HOLDING_ID
          AND cust_alloc.DEFINITION =
                 REPLACE (alloc.DEFINITION, 'DealerRoom', 'Customer')
          AND btxn.PARENT_TRANSACTION_ID = ptxn.id
          AND alloc.PARENT_TRANSACTION_ID = btxn.id
          AND ptxn.id = rel.TO_ID
/
