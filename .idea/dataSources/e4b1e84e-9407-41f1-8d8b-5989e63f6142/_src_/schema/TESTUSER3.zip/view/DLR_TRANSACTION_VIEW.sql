CREATE VIEW DLR_TRANSACTION_VIEW AS SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
alloc.definition alloc_definition,
alloc.processed_date processed_date,
alloc.PARENT_TRANSACTION_ID PARENT_TXN_ID,
alloc.id alloc_txn_id,
ptxn.state state,
'1' ALLOC_TXN_ID_BUSINESS_ID,
alloc.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
ROUND (alloc.resultant_unit_quantity,6) balance,
DECODE (alloc.direction,'-',-1 * alloc.currency_quantity,alloc.currency_quantity) rands,
DECODE (alloc.direction,'-',-1 * alloc.unit_quantity2,alloc.unit_quantity2) units,
alloc.direction,
alloc.currency_quantity,
alloc.unit_quantity2,
alloc.resultant_unit_quantity,
alloc.denomination_id denom FROM dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = ptxn.id
AND (ptxn.state = 'Finalised' OR ptxn.state = 'Reversed&Replaced')
AND alloc.definition LIKE '%Allocation'
AND h.id = alloc.holding_id
AND inv.id = h.value_id
UNION
ALL
SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
contra.definition alloc_definition,
alloc.processed_date processed_date,
contra.PARENT_TRANSACTION_ID PARENT_TXN_ID,
contra.id alloc_txn_id,
ptxn.state state,
'1' ALLOC_TXN_ID_BUSINESS_ID,
contra.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
ROUND (contra.resultant_unit_quantity,6) balance,
DECODE (contra.direction,'-',-1 * alloc.currency_quantity,alloc.currency_quantity) rands,
DECODE (contra.direction,'-',-1 * alloc.unit_quantity2,alloc.unit_quantity2) units,
contra.direction,
alloc.currency_quantity,
alloc.unit_quantity2,
contra.resultant_unit_quantity,
alloc.denomination_id denom FROM dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
dlr_dlr_transaction contra,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = ptxn.id
AND contra.parent_transaction_id = alloc.id
AND (ptxn.state = 'Finalised' OR ptxn.state = 'Reversed&Replaced')
AND h.id = contra.holding_id
AND inv.id = h.value_id
AND contra.definition LIKE '%Contra'
UNION
ALL
SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
alloc.definition alloc_definition,
alloc.processed_date processed_date,
alloc.PARENT_TRANSACTION_ID PARENT_TXN_ID,
alloc.id alloc_txn_id,
ptxn.state state,
'1' ALLOC_TXN_ID_BUSINESS_ID,
alloc.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
ROUND (alloc.resultant_unit_quantity,6) balance,
DECODE (alloc.direction,'-',-1 * alloc.currency_quantity,alloc.currency_quantity) rands,
DECODE (alloc.direction,'-',-1 * alloc.unit_quantity2,alloc.unit_quantity2) units,
alloc.direction,
alloc.currency_quantity,
alloc.unit_quantity2,
alloc.resultant_unit_quantity,
alloc.denomination_id denom FROM dlr_dlr_transaction pptxn,
dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
dlr_dlr_transaction contra,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = pptxn.id
AND pptxn.parent_transaction_id = ptxn.id
AND contra.parent_transaction_id = alloc.id
AND (ptxn.state = 'Finalised' OR ptxn.state = 'Reversed&Replaced')
AND alloc.definition LIKE '%Allocation'
AND h.id = alloc.holding_id
AND inv.id = h.value_id
UNION
ALL
SELECT
ptxn.EXTERNAL_REFERENCE,
ptxn.effective_date effective_date,
contra.definition alloc_definition,
alloc.processed_date processed_date,
contra.PARENT_TRANSACTION_ID PARENT_TXN_ID,
contra.id alloc_txn_id,
ptxn.state state,
'1' ALLOC_TXN_ID_BUSINESS_ID,
contra.holding_id holding_id,
alloc.INVESTMENT_ID,
inv.EXTERNAL_REFERENCE porno,
ROUND (contra.resultant_unit_quantity,6) balance,
DECODE (contra.direction,'-',-1 * alloc.currency_quantity,alloc.currency_quantity) rands,
DECODE (contra.direction,'-',-1 * alloc.unit_quantity2,alloc.unit_quantity2) units,
contra.direction,
alloc.currency_quantity,
alloc.unit_quantity2,
contra.resultant_unit_quantity,
alloc.denomination_id denom FROM dlr_dlr_transaction ptxn,
dlr_dlr_transaction pptxn,
dlr_dlr_transaction alloc,
dlr_dlr_transaction contra,
dlr_holding h,
dlr_investment inv
WHERE alloc.parent_transaction_id = pptxn.id
AND contra.parent_transaction_id = alloc.id
AND pptxn.parent_transaction_id = ptxn.id
AND (ptxn.state = 'Finalised' OR ptxn.state = 'Reversed&Replaced')
AND h.id = contra.holding_id
AND inv.id = h.value_id
AND contra.definition LIKE '%Contra'
ORDER BY processed_date,alloc_txn_id
/
