CREATE VIEW SM_ROLE_PAGER_FORWARD AS SELECT role_id, displayName
       FROM sm_role
   ORDER BY role_id
/
