CREATE VIEW SM_ACCOUNT_PAGER_BACKWARD AS SELECT account_id, displayName, webName
       FROM sm_account
   ORDER BY LPAD (account_id, 10, '0') DESC
/
