CREATE VIEW DLR_ORBIT_ADVICES AS SELECT orbit_trade.conno,
          orbit_trade.GRPNO,
          orbit_trade.PORNO,
          orbit_trade.RANDS,
          orbit_trade.UNITS,
          orbit_trade.TRADENO,
          orbit_trade.TRANSACTION_STATE,
          orbit_trade.ALLOC_ID,
          orbit_trade.DEFINITION,
          orbit_trade.EFFECTIVE_DATE,
          orbit_trade.TRADE_DATE,
          orbit_trade.INVESTMENT_ID,
          orbit_trade.ALLOC_HOLDING,
          orbit_trade.DENOMINATION,
          orbit_trade.TRADER_TXN_ID,
          advice.ACCOUNT,
          advice.SUB_ACCOUNT,
          advice.UNIT_INSTRUCTION_TYPE,
          advice.AMOUNT,
          advice.ADVICE_TYPE,
          advice.DIRECTION,
          advice.INVESTMENT_NAME,
          advice.STRATEGY_NAME,
          advice.TRADE_DATE "advice_date",
          advice.INSTRUCTION_ID,
          advice.TXN_REF_ID,
          advice.DOCUMENT_REFERENCE,
          advice.ADVICE_DETAIL,
          advice.INSTRUCTION_TYPE,
          advice.OWNER_NAME,
          advice.OWNER_DESCRIPTION,
          advice.SUPPLIER_HOLDING_ID,
          advice.TRADER_HOLDING_ID
     FROM (SELECT r.name conno,
                  p.name grpno,
                  inv.external_reference porno,
                  ROUND (alloc.currency_quantity, 2) rands,
                  ROUND (alloc.unit_quantity2, 6) units,
                  ptxn.EXTERNAL_REFERENCE tradeno,
                  ptxn.state transaction_state,
                  alloc.id alloc_id,
                  alloc.DEFINITION,
                  ptxn.EFFECTIVE_DATE,
                  trader_inxn.EFFECTIVE_DATE trade_date,
                  alloc.INVESTMENT_ID,
                  alloc.HOLDING_ID alloc_holding,
                  alloc.DENOMINATION_ID denomination,
                  tcontra.id trader_txn_id
             FROM DLR_RELATIONSHIP rel,
                  dlr_instruction trader_inxn,
                  DLR_DLR_TRANSACTION alloc,
                  dlr_dlr_transaction ptxn,
                  dlr_holding h,
                  dlr_portfolio p,
                  dlr_role r,
                  dlr_investment inv,
                  dlr_dlr_transaction tcontra,
                  dlr_dlr_transaction talloc,
                  dlr_dlr_transaction tptxn
            WHERE     rel.TYPE = 'trade'
                  AND trader_inxn.id = rel.FROM_ID
                  AND alloc.id = rel.TO_ID
                  AND ptxn.id = alloc.PARENT_TRANSACTION_ID
                  AND h.id = alloc.HOLDING_ID
                  AND p.id = h.PORTFOLIO_ID
                  AND r.id = p.ROLE_ID
                  AND inv.id = alloc.INVESTMENT_ID
                  AND tcontra.parent_transaction_id = talloc.id
                  AND talloc.parent_transaction_id = tptxn.id
                  AND tptxn.EXTERNAL_REFERENCE = trader_inxn.id
                  AND tptxn.EFFECTIVE_DATE = trader_inxn.effective_date)
          orbit_trade,
          DLR_ADVICES_VIEW2 advice
    WHERE advice.txn_ref_ID = orbit_trade.trader_txn_id
/
