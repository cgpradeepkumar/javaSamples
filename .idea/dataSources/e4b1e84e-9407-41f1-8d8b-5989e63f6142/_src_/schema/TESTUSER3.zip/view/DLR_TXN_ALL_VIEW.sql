CREATE VIEW DLR_TXN_ALL_VIEW AS SELECT ptxn.SETTLEMENT_STATE settle_state,
            alloc.trade_state,
            alloc.processed_date,
            ptxn.external_reference trade_no,
            ptxn.id txn_id,
            alloc.currency_quantity rands,
            alloc.unit_quantity2 uq_units,
            alloc.denomination_id,
            ptxn.effective_date,
            ptxn.definition,
            ier.state price_state,
            ier.effective_date price_date,
            alloc.investment_id,
            v.value_name,
            inv.external_reference orbit_portfolio,
            state.name state,
            r.name conno,
            p.name grpno,
            h.id holding,
            inv.INVESTMENT_SUPPLIER_ID
       FROM dlr_dlr_transaction ptxn,
            dlr_dlr_transaction alloc,
            dlr_investment_exchange_rate ier,
            dlr_investment inv,
            dlr_value v,
            dlr_transaction_state state,
            dlr_dlr_transaction contra,
            dlr_holding h,
            dlr_portfolio p,
            dlr_role r
      WHERE     alloc.parent_transaction_id = ptxn.id
            AND ptxn.parent_transaction_id IS NULL
            AND h.id = alloc.holding_id
            AND p.id = h.portfolio_id
            AND r.id = p.role_id
            AND ier.id = alloc.price
            AND inv.id = alloc.investment_id
            AND v.id = inv.id
            AND state.id = ptxn.transaction_state
            AND contra.parent_transaction_id = alloc.id
   ORDER BY alloc.PROCESSED_DATE, ptxn.id
/
