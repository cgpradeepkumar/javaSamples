CREATE VIEW DLR_VIEW_INVESTMENT_SUPPLIERS AS SELECT
dlr_role.ID investment_supplier_id,
dlr_role.NAME investment_supplier_orbit_name,
dlr_role.DESCRIPTION investment_supplier_name,
dlr_portfolio.ID portfolio_id,
dlr_portfolio.NAME portfolio_name,
supplierHolding.ID holding_id,
supplierHolding.HOLDING_NAME,
dlr_product_strategy.STRATEGY_NAME product_strategy,
dlr_investment.ID investment_id,
dlr_value.VALUE_NAME investment_name,
dlr_investment.EXTERNAL_REFERENCE investment_orbit_name,
currency.value_name currency_code,
status.name investment_trade_state,
dlr_investment_sup_portfolio.external_reference am_account,
supplierHolding.external_reference am_sub_account FROM dlr_holding supplierHolding,
dlr_portfolio,
dlr_investment_sup_portfolio,
dlr_investment_tdr_portfolio,
dlr_product_strategy,
dlr_holding traderHolding,
dlr_relationship,
dlr_role,
dlr_value,
dlr_value currency,
dlr_investment,
dlr_investment_trade_state status
WHERE dlr_investment.ID = supplierHolding.VALUE_ID
AND status.investment_id = dlr_investment.id
AND dlr_value.ID = dlr_investment.ID
and currency.id=DLR_value.value_id
AND dlr_investment_sup_portfolio.ID = supplierHolding.PORTFOLIO_ID
AND dlr_portfolio.ID = dlr_investment_sup_portfolio.ID
AND dlr_role.ID = dlr_portfolio.ROLE_ID
AND dlr_relationship.TYPE = 'Trader Holding'
AND dlr_relationship.FROM_ID = supplierHolding.id
AND traderHolding.id = dlr_relationship.TO_ID
AND dlr_investment_tdr_portfolio.id = traderHolding.PORTFOLIO_ID
AND dlr_product_strategy.ID = dlr_investment_tdr_portfolio.PRODUCT_STRATEGY_ID
/
