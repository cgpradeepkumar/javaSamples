CREATE VIEW DLR_TRADE_COUNT AS select AMNNO,EFFECTIVE_DATE,TXN_STATE,INVESTMENT_ID,DEFINITION,ADVICE_STATE,TRADE_COUNT
 from 
(select   inv_owner.name amnno,ptxn.effective_date,ptxn.STATE txn_state,alloc.INVESTMENT_ID,ptxn.DEFINITION,ptxn.ADVICE_STATE, count(*) trade_count
from dlr_dlr_transaction ptxn
	join dlr_dlr_transaction alloc on (alloc.PARENT_TRANSACTION_ID=ptxn.id)
	join dlr_holding h on (h.id=alloc.HOLDING_ID)
	join DLR_INVESTMENT_TDR_PORTFOLIO trader_portfolio on  (trader_portfolio.id=h.PORTFOLIO_ID)
	join dlr_portfolio p on ( p.id=h.PORTFOLIO_ID)
	join  DLR_INVESTMENT inv on (inv.id=h.VALUE_ID)
	join dlr_role inv_owner on ( inv_owner.id=inv.INVESTMENT_SUPPLIER_ID)
     join dlr_trade_param params on (params.effective_date=ptxn.effective_date and params.amnno=inv_owner.name)
where 
ptxn.PARENT_TRANSACTION_ID is null 
and ptxn.advice_state='Advised'
group by ptxn.EFFECTIVE_DATE,ptxn.STATE,alloc.INVESTMENT_ID,inv_owner.name,ptxn.DEFINITION,ptxn.ADVICE_STATE
)
/
