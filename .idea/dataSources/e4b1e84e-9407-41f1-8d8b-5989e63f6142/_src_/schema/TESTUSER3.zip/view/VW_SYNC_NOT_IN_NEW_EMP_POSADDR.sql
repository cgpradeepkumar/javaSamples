CREATE VIEW VW_SYNC_NOT_IN_NEW_EMP_POSADDR AS SELECT O."TYPE",
          O."EMPLOYER",
          O."LINE_ONE_DETAILS",
          O."LINE_TWO_DETAILS",
          O."LINE_THREE_DETAILS",
          O."LINE_FOUR_DETAILS",
          O."CODE",
          O."REFERENCE_KEY",
          O."ISSUED",
          O."SUBMITTER",
          O."DIRECTIVE_TYPE",
          O."SCHEME",
          O."CREATE_DATE",
          O."DIRECTIVE_STATUS",
          O."DIRECTIVE_STATUS_DATE",
          O."SURNAME",
          O."FIRST_NAMES",
          O."INITIALS",
          O."DATE_OF_BIRTH",
          O."SA_ID_NUMBER",
          O."OTHER_ID_NUMBER",
          O."MEMBER_NUMBER",
          O."NO_TAX_REF_REASON_OTHER",
          O."NO_TAX_REF_REASON",
          O."ANCESTOR_KEY",
          O."BATCH",
          O."EMPLOYEE_NUMBER",
          O."TAX_REF_NUMBER",
          O."REASON",
          O."CONTACT_NAME_TEL_NO",
          O."CONTACT_NAME_DIAL_CODE",
          O."GROUP_NAME",
          O."GROUP_CODE",
          O."CONTACT_FIRST_NAME",
          O."CONTACT_SURNAME",
          O."PUBLIC_SEC_START_DATE",
          O."PUBLIC_SEC_END_DATE",
          O."PUBLIC_SEC_TFR_AMOUNT",
          O."PUBLIC_SEC_TFR_DATE",
          O."CANCEL_REASON",
          O."UNCLAIMED_BENEF_PREV_TAXED",
          O."ID",
          O."DESCRIPTION"
     FROM (SELECT A.*, D.*, AT.*
             FROM (SELECT *
                     FROM MTAX_EMPLOYER_ADDRESS
                    WHERE    LINE_ONE_DETAILS IS NOT NULL
                          OR LINE_TWO_DETAILS IS NOT NULL
                          OR LINE_THREE_DETAILS IS NOT NULL
                          OR LINE_FOUR_DETAILS IS NOT NULL) A
                  INNER JOIN MTAX_DIRECTIVE D ON A.EMPLOYER = D.REFERENCE_KEY
                  LEFT JOIN MTAX_DIRECTIVES_TO_NOT_MIGRATE EXC
                     ON D.REFERENCE_KEY = EXC.REFERENCE_KEY
                  INNER JOIN MTAX_ADDRESS_TYPE AT ON A.TYPE = AT.ID
            WHERE A.TYPE = 1 AND EXC.REFERENCE_KEY IS NULL) O
          LEFT JOIN
          (SELECT *
             FROM MTD_ADDRESS A
                  INNER JOIN MTD_DIRECTIVE_REQUEST R
                     ON A.ADDRESS_ID = R.EMP_POST_ADDRESS_ID) N
             ON N.REQ_SEQ_NUM = O.REFERENCE_KEY
    WHERE N.REQ_SEQ_NUM IS NULL
/
