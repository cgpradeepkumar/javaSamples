CREATE VIEW DLR_TDR_SUP_BAL_VIEW AS SELECT
r.name supplier_name,
r.description,
r.id role_id,
p.name account_name,
h.id supplier_holding_id,
rel.to_id trader_holding,
supp.ID spid,
inv.id investment_id,
inv.external_reference porno,
v.value_name,
ps.STRATEGY_NAME,
h.external_reference subAccount,
supp.external_reference accountName,
p.id portfolio_id,
p.description portf_descr,
ROUND (th.UNIT_QUANTITY, 6) trader_balance,
ROUND (h.UNIT_QUANTITY, 6) supplier_bal,
supp.external_reference
FROM dlr_holding h
JOIN dlr_investment inv ON (h.VALUE_ID = inv.id)
JOIN dlr_portfolio p ON (p.id = h.portfolio_id)
JOIN dlr_investment_sup_portfolio supp ON (supp.id = p.id)
JOIN dlr_role r ON (p.role_id = r.id)
JOIN dlr_value v ON (v.id = inv.id)
JOIN dlr_relationship rel ON
(
   rel.from_id = h.id
   AND rel.TYPE = 'Trader Holding'
)
JOIN dlr_holding th ON (th.id = rel.to_id)
JOIN DLR_INVESTMENT_TDR_PORTFOLIO itp ON (itp.id = th.PORTFOLIO_ID)
JOIN DLR_PRODUCT_STRATEGY ps ON (ps.id = itp.PRODUCT_STRATEGY_ID)
JOIN dlr_investment_tdr_portfolio tp ON (th.portfolio_id = tp.id)
/
