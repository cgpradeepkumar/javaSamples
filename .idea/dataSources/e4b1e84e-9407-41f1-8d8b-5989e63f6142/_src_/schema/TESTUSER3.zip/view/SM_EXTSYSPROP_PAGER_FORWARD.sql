CREATE VIEW SM_EXTSYSPROP_PAGER_FORWARD AS SELECT extsysprop_id, extsys_id, displayName
       FROM sm_extsysprop
   ORDER BY extsysprop_id
/
