CREATE VIEW DLR_INVO_STRUCTURE_VIEW AS SELECT r.name broker_name,
            r.description broker_description,
            p.name scheme_name,
            p.description scheme_description,
            h.id holding_id,
            ROUND (h.unit_quantity, 6) current_balance,
            inv.external_reference porno,
            v.value_name,
            ps.strategy_name
       FROM dlr_holding h,
            dlr_investment inv,
            dlr_portfolio p,
            dlr_investor_portfolio ip,
            dlr_role r,
            dlr_value v,
            dlr_product_strategy ps
      WHERE     inv.id = h.value_id
            AND p.id = h.portfolio_id
            AND p.role_id = r.id
            AND v.id = inv.id
            AND ip.id = p.id
            AND ps.id = ip.product_strategy_id
            AND ps.strategy_name = 'Invo'
   ORDER BY r.name, p.name, v.value_name
/
