CREATE VIEW VW_DM_CLASSES AS SELECT C_3.DOMAIN_ID,
          C_3.CLASS_ID,
          C_1.CLASS_ID || '\' || C_2.CLASS_ID || '\' || C_3.CLASS_ID
             AS CLASS_IDS,
          C_1.NAME || '\' || C_2.NAME || '\' || C_3.NAME AS CLASS_PATH,
          '3' AS LEVELS
     FROM ((    SELECT C3.DOMAIN_ID,
                       C3.CLASS_ID,
                       C3.PARENT_CLASS_ID,
                       C3.NAME,
                       LEVEL
                  FROM DM_CLASS C3
                 WHERE LEVEL = 3
            CONNECT BY PRIOR CLASS_ID = PARENT_CLASS_ID
            START WITH PARENT_CLASS_ID IS NULL) C_3
           LEFT JOIN (    SELECT C2.DOMAIN_ID,
                                 C2.CLASS_ID,
                                 C2.PARENT_CLASS_ID,
                                 C2.NAME,
                                 LEVEL
                            FROM DM_CLASS C2
                           WHERE LEVEL = 2
                      CONNECT BY PRIOR CLASS_ID = PARENT_CLASS_ID
                      START WITH PARENT_CLASS_ID IS NULL) C_2
              ON C_2.CLASS_ID = C_3.PARENT_CLASS_ID
           LEFT JOIN (    SELECT C1.DOMAIN_ID,
                                 C1.CLASS_ID,
                                 C1.PARENT_CLASS_ID,
                                 C1.NAME,
                                 LEVEL
                            FROM DM_CLASS C1
                           WHERE LEVEL = 1
                      CONNECT BY PRIOR CLASS_ID = PARENT_CLASS_ID
                      START WITH PARENT_CLASS_ID IS NULL) C_1
              ON C_1.CLASS_ID = C_2.PARENT_CLASS_ID)
   UNION
   (SELECT C_2.DOMAIN_ID,
           C_2.CLASS_ID,
           C_1.CLASS_ID || '\' || C_2.CLASS_ID,
           C_1.NAME || '\' || C_2.NAME,
           '2' AS LEVELS
      FROM ((    SELECT C2.DOMAIN_ID,
                        C2.CLASS_ID,
                        C2.PARENT_CLASS_ID,
                        C2.NAME,
                        LEVEL
                   FROM DM_CLASS C2
                  WHERE LEVEL = 2
             CONNECT BY PRIOR CLASS_ID = PARENT_CLASS_ID
             START WITH PARENT_CLASS_ID IS NULL) C_2
            LEFT JOIN (    SELECT C1.DOMAIN_ID,
                                  C1.CLASS_ID,
                                  C1.PARENT_CLASS_ID,
                                  C1.NAME,
                                  LEVEL
                             FROM DM_CLASS C1
                            WHERE LEVEL = 1
                       CONNECT BY PRIOR CLASS_ID = PARENT_CLASS_ID
                       START WITH PARENT_CLASS_ID IS NULL) C_1
               ON C_1.CLASS_ID = C_2.PARENT_CLASS_ID))
   UNION
   (    SELECT C1.DOMAIN_ID,
               C1.CLASS_ID,
               TO_CHAR (C1.CLASS_ID),
               C1.NAME,
               '1' AS LEVELS
          FROM DM_CLASS C1
         WHERE LEVEL = 1
    CONNECT BY PRIOR CLASS_ID = PARENT_CLASS_ID
    START WITH PARENT_CLASS_ID IS NULL)
   ORDER BY LEVELS, DOMAIN_ID, CLASS_ID
/
