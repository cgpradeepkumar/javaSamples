CREATE VIEW VW_SYNC_IN_TP_POSADDR AS SELECT O."TYPE",
          O."LINE_ONE_DETAILS",
          O."LINE_TWO_DETAILS",
          O."LINE_THREE_DETAILS",
          O."LINE_FOUR_DETAILS",
          O."CODE",
          O."REFERENCE_KEY"
     FROM (SELECT A.*
             FROM MTAX_TAXPAYER_ADDRESS A
                  INNER JOIN MTAX_DIRECTIVE D
                     ON A.REFERENCE_KEY = D.REFERENCE_KEY
                  INNER JOIN MTAX_ADDRESS_TYPE AT ON A.TYPE = AT.ID
            WHERE A.TYPE = 1) O
          INNER JOIN
          (SELECT *
             FROM MTD_ADDRESS A
                  INNER JOIN MTD_DIRECTIVE_REQUEST R
                     ON A.ADDRESS_ID = R.TP_POST_ADDRESS_ID) N
             ON N.REQ_SEQ_NUM = O.REFERENCE_KEY
/
