CREATE VIEW VW_SYNC_NOT_IN_NEW_FUND AS SELECT O."ID",
          O."FUND_NAME",
          O."PRODUCT_TYPE",
          O."CREATE_REASON",
          O."APPROVAL_NUMBER",
          O."PAYE_NUMBER",
          O."PRIVATE",
          O."ORBIT_CONTRACT",
          O."ACTIVE",
          O."ACTIVE_REASON"
     FROM (SELECT S.ID,
                  UPPER (TRIM (S.FUND_NAME)) AS FUND_NAME,
                  S.PRODUCT_TYPE,
                  S.CREATE_REASON,
                  S.APPROVAL_NUMBER,
                  S.PAYE_NUMBER,
                  S.PRIVATE,
                  S.ORBIT_CONTRACT,
                  S.ACTIVE,
                  S.ACTIVE_REASON
             FROM MTAX_SCHEME S
           UNION
           SELECT S.ID,
                  UPPER (TRIM (S.FUND_NAME)) AS FUND_NAME,
                  S.PRODUCT_TYPE,
                  S.CREATE_REASON,
                  S.APPROVAL_NUMBER,
                  C.PAYE_NUMBER,
                  S.PRIVATE,
                  S.ORBIT_CONTRACT,
                  S.ACTIVE,
                  S.ACTIVE_REASON
             FROM MTAX_SCHEME S
                  INNER JOIN (SELECT * FROM VW_MTAX_CERT_PAYE_PROB) C
                     ON S.ID = C.CONTRACT_NUMBER) O
          LEFT JOIN
          (SELECT *
             FROM MTD_FUND F
                  INNER JOIN MTD_FUND_GROUP FG
                     ON F.FUND_GROUP_ID = FG.FUND_GROUP_ID) N
             ON     N.CONTRACT_NUMBER = O.ID
                AND N.FUND_NUMBER = O.APPROVAL_NUMBER
                AND N.FUND_PAYE_NO = O.PAYE_NUMBER
    WHERE     N.CONTRACT_NUMBER IS NULL
          AND N.FUND_NUMBER IS NULL
          AND N.FUND_PAYE_NO IS NULL
/
