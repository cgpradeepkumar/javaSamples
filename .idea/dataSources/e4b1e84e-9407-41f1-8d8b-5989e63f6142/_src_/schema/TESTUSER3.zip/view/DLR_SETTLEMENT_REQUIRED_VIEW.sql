CREATE VIEW DLR_SETTLEMENT_REQUIRED_VIEW AS SELECT ptxn.SETTLEMENT_METHOD,
            ptxn.SETTLEMENT_STATE,
            ptxn.EXTERNAL_REFERENCE trdno,
            state.name txn_state,
            state.id state_id,
            ptxn.id ptxn_id,
            ptxn.EFFECTIVE_DATE,
            alloc.PROCESSED_DATE,
            ptxn.DEFINITION,
            alloc.HOLDING_ID a_h_id,
            contra.HOLDING_ID c_h_id,
            alloc.INVESTMENT_ID,
            r.NAME conno,
            p.NAME grpno,
            inv.EXTERNAL_REFERENCE porno,
            alloc.currency_quantity rands,
            alloc.unit_quantity2 units,
            alloc.DENOMINATION_ID
       FROM DLR_DLR_TRANSACTION ptxn,
            DLR_DLR_TRANSACTION alloc,
            dlr_dlr_transaction contra,
            DLR_INVESTMENT inv,
            dlr_role r,
            dlr_portfolio p,
            dlr_holding h,
            dlr_transaction_state state
      WHERE     alloc.PARENT_TRANSACTION_ID = ptxn.id
            AND inv.id = alloc.INVESTMENT_ID
            AND h.PORTFOLIO_ID = p.id
            AND r.id = p.ROLE_ID
            AND h.id = alloc.HOLDING_ID
            AND state.id = ptxn.TRANSACTION_STATE
            AND alloc.DEFINITION LIKE '%Allocation'
            AND contra.PARENT_TRANSACTION_ID = alloc.id
            AND ptxn.SETTLEMENT_STATE = 'SettlementRequired'
   ORDER BY alloc.HOLDING_ID, alloc.PROCESSED_DATE
/
