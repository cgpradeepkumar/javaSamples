CREATE VIEW VW_MTAX_TRFUND_TYPE_DUPLICATES AS SELECT "APPROVAL_NUMBER", "XFER_FUND_TYPE", "XFER_FUND_NAME"
       FROM VW_MTAX_TRANSFER_FUNDS
      WHERE (APPROVAL_NUMBER, XFER_FUND_TYPE) IN (  SELECT APPROVAL_NUMBER,
                                                           XFER_FUND_TYPE
                                                      FROM VW_MTAX_TRANSFER_FUNDS
                                                  GROUP BY APPROVAL_NUMBER,
                                                           XFER_FUND_TYPE
                                                    HAVING COUNT (*) > 1)
   ORDER BY APPROVAL_NUMBER, XFER_FUND_TYPE, XFER_FUND_NAME
/
