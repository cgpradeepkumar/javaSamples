CREATE VIEW SM_EXTSYS_PAGER_BACKWARD AS SELECT extsys_id, displayName
       FROM sm_extsys
   ORDER BY extsys_id DESC
/
