CREATE VIEW VW_SYNC_NOT_IN_NEW_CERT_DIR AS SELECT O."NEW_DIRECTIVE_ID",
          O."CERTIFICATE_REF_NO",
          O."TAX_YEAR",
          O."PAYE_NUMBER"
     FROM (SELECT C.*
             FROM (SELECT *
                     FROM (SELECT DISTINCT NEW_DIRECTIVE_ID,
                                           CERTIFICATE_REF_NO,
                                           TO_NUMBER (TAX_YEAR) AS TAX_YEAR,
                                           PAYE_NUMBER
                             FROM MTAX_CERTIFICATE
                            WHERE     TAX_CERT_TYPE IN (1, 2)
                                  AND DIR_ID_NUMERIC = 1)) C
                  INNER JOIN VW_MTAX_OLD_DIRRESP_ALL DR
                     ON C.NEW_DIRECTIVE_ID = DR.DIRECTIVE_ID
                  INNER JOIN MTAX_DIRECTIVE D
                     ON DR.REFERENCE_KEY = D.REFERENCE_KEY) O
          LEFT JOIN
          (SELECT *
             FROM MTD_CERTIFICATE C
                  INNER JOIN MTD_DIRECTIVE_RESPONSE DR
                     ON C.DIRECTIVE_RESPONSE_ID = DR.DIRECTIVE_RESPONSE_ID
                  INNER JOIN MTD_DIRECTIVE_REQUEST D
                     ON DR.DIRECTIVE_REQUEST_ID = D.DIRECTIVE_REQUEST_ID) N
             ON N.DIRECTIVE_NUMBER = O.NEW_DIRECTIVE_ID
    WHERE N.DIRECTIVE_NUMBER IS NULL
/
