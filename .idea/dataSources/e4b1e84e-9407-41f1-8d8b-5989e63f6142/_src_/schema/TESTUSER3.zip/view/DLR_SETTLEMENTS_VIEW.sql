CREATE VIEW DLR_SETTLEMENTS_VIEW AS SELECT i.id instruction_ID,
            i.EFFECTIVE_DATE,
            i.state,
            ROUND (SI.TOTAL_AMOUNT_QUANTITY, 2) rands,
            si.settle_service,
            pd.reference,
            them.ACCOUNT_NUMBER
       FROM dlr_instruction i,
            dlr_settlement_instruction si,
            DLR_SETTLEMENT_PARTY_DETAIL pd,
            dlr_settlement_element se,
            DLR_SETTLEMENT_PARTY_DETAIL them
      WHERE     si.id = i.id
            AND se.instruction_id = i.id
            AND them.id = se.them_settle_party_id
            AND pd.id = si.us_settle_party_id
   ORDER BY i.id
/
