CREATE VIEW VW_MTAX_TRFUND_APPROVALNO_PROB AS SELECT APPROVAL_NUMBER,
            LENGTH (APPROVAL_NUMBER) AS APPROVALNO_LENGTH,
            LENGTH (TRIM (APPROVAL_NUMBER)) AS TRIM_APPROVALNO_LENGTH,
            FUND_NAME
       FROM MTAX_TRANSFER_FUNDS
      WHERE    ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 1, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 2, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 3, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 4, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 5, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 6, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 7, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 8, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 9, 1)) NOT BETWEEN 48
                                                                      AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 10, 1)) NOT BETWEEN 48
                                                                       AND 57
            OR ASCII (SUBSTR (RTRIM (APPROVAL_NUMBER), 11, 1)) NOT BETWEEN 48
                                                                       AND 57
            OR LENGTH (RTRIM (APPROVAL_NUMBER)) < 8
            OR LENGTH (RTRIM (APPROVAL_NUMBER)) > 11
            OR APPROVAL_NUMBER NOT LIKE '18204%'
   ORDER BY FUND_NAME, APPROVAL_NUMBER
/
