CREATE VIEW DLR_TXN_TO_FINALISE_VIEW AS select
decode(inv.CONFIRM_TXN_EFF_DATE,1,decode(nvl(tdc.TRANSACTION_ID,1),1,'Waiting for confirmation from AM','Confirmation received from AM'),'Not waiting for confirmation from AM') confirm_state,
case when inv.CONFIRM_TXN_EFF_DATE = 1 
then 
	case when nvl(tdc.TRANSACTION_ID,1) = 1 
	then 
		'Waiting for confirmation from AM'			
	else 
		case when nvl(tdc.APPLIED_DATE, to_date('9999','yyyy')) = to_date('9999','yyyy')
		then
			'Confirmation received from AM, need to apply date change'
		else
			case when ier.state != 'AUTHORISED' 
			then
				'DateChange applied, waiting for AUTHORISED Price'
			else
				'Need to run Finalise' 
			end
		end	  
	end
else
	case when ier.state != 'AUTHORISED' then
	'Waiting for AUTHORISED Price'
	else
	'Need to run Finalise' 
	end
end process_trigger,
to_date(sysdate)-ptxn.effective_date txn_age,
ier.state price_state,
ptxn.external_reference,
ptxn.id ptxn_id,
alloc.currency_quantity rands,
alloc.unit_quantity2 units,
ptxn.effective_date,
alloc.definition,
ier.effective_date price_date,
alloc.investment_id,
v.value_name,
inv.external_reference porno,
alloc.denomination_id,
ptxn.state txn_state,
r.name conno,
p.name grpno,
h.id holding_id
from dlr_dlr_transaction ptxn join dlr_dlr_transaction alloc on (alloc.PARENT_TRANSACTION_ID=ptxn.id)
left join dlr_investment_exchange_rate ier on (ier.id=alloc.PRICE)
join dlr_investment inv on (inv.id=alloc.INVESTMENT_ID) join dlr_value v on (v.id=inv.id)
join dlr_holding h on (h.id=alloc.HOLDING_ID)
join dlr_portfolio p on (p.ID=h.PORTFOLIO_ID)
join dlr_role r on (r.id=p.ROLE_ID)
left join DLR_TXN_DATE_CHANGE tdc on (tdc.TRANSACTION_ID=ptxn.id) -- left join to show which txn_date_changes have not yet arrived
where ptxn.parent_transaction_id is null
and ptxn.state='Authorized'
and alloc.DEFINITION like '%/Allocation'
	union
select
decode(inv.CONFIRM_TXN_EFF_DATE,1,decode(nvl(tdc.TRANSACTION_ID,1),1,'Waiting for confirmation from AM','Confirmation received from AM'),'Not waiting for confirmation from AM') confirm_state,
case when inv.CONFIRM_TXN_EFF_DATE = 1 
then 
	case when nvl(tdc.TRANSACTION_ID,1) = 1 
	then 
		'Waiting for confirmation from AM'			
	else 
		case when nvl(tdc.APPLIED_DATE, to_date('00000000','yyyymmdd')) = to_date('00000000','yyyymmdd')
		then
			'Confirmation received from AM, need to apply date change'
		else
			case when ier.state != 'AUTHORISED' 
			then
				'DateChange applied, waiting for AUTHORISED Price'
			else
				'Need to run Finalise' 
			end
		end	  
	end
else
	case when ier.state != 'AUTHORISED' then
	'Waiting for AUTHORISED Price'
	else
	'Need to run Finalise' 
	end
end process_trigger,
	to_date(sysdate)-ptxn.effective_date txn_age,
ier.state price_state,
ptxn.external_reference,
ptxn.id ptxn_id,
alloc.currency_quantity rands,
alloc.unit_quantity2 units,
ptxn.effective_date,
alloc.definition,
ier.effective_date price_date,
alloc.investment_id,
v.value_name,
inv.external_reference porno,
alloc.denomination_id,
ptxn.state txn_state,
r.name conno,
p.name grpno,
h.id holding_id
from dlr_dlr_transaction ptxn join dlr_dlr_transaction btxn on (btxn.PARENT_TRANSACTION_ID=ptxn.id) join dlr_dlr_transaction alloc on (alloc.PARENT_TRANSACTION_ID=btxn.id)
left join dlr_investment_exchange_rate ier on (ier.id=alloc.PRICE)
join dlr_investment inv on (inv.id=alloc.INVESTMENT_ID) join dlr_value v on (v.id=inv.id)
join dlr_holding h on (h.id=alloc.HOLDING_ID)
join dlr_portfolio p on (p.ID=h.PORTFOLIO_ID)
join dlr_role r on (r.id=p.ROLE_ID)
left join DLR_TXN_DATE_CHANGE tdc on (tdc.TRANSACTION_ID=ptxn.id) -- left join to show which txn_date_changes have not yet arrived 
where ptxn.parent_transaction_id is null
and ptxn.state='Authorized'
and alloc.DEFINITION like '%/Allocation'
/
