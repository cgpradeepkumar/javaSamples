CREATE VIEW DLR_AM_FEE_VIEW AS SELECT r.name conno,
          p.name grpno,
          inv.external_reference porno,
          alloc.holding_id alloc_holding_id,
          contra.holding_id trader_holding,
          alloc.currency_quantity fee,
          mf.amount_quantity total_mfamount,
          mf.period_end_date,
          itd.date_distributed
     FROM dlr_dlr_transaction alloc,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction contra,
          dlr_information_to_distribute itd,
          dlr_relationship rel,
          dlr_management_fee mf,
          dlr_holding h,
          dlr_portfolio p,
          dlr_role r,
          dlr_investment inv
    WHERE     alloc.definition LIKE '%Fee%Allocation'
          AND ptxn.id = alloc.parent_transaction_id
          AND ptxn.effective_date = mf.period_end_date
          AND contra.parent_transaction_id = alloc.id
          AND itd.information_id = ptxn.id
          AND rel.to_id = mf.holding_id
          AND contra.holding_id = rel.from_id
          AND h.id = alloc.holding_id
          AND p.id = h.portfolio_id
          AND r.id = p.role_id
          AND inv.id = h.value_id
/
