CREATE VIEW DLR_DIV_VIEW AS SELECT ptxn.id,
          ptxn.effective_date,
          ptxn.definition,
          itd.is_distributed,
          alloc.holding_id,
          itd.date_distributed,
          r.name conno,
          p.name grpno,
          inv.external_reference porno,
          ROUND (alloc.currency_quantity, 2) amount,
          ROUND (alloc.unit_quantity2, 6) units
     FROM dlr_dlr_transaction alloc,
          dlr_dlr_transaction ptxn,
          dlr_information_to_distribute itd,
          dlr_portfolio p,
          dlr_role r,
          dlr_holding h,
          dlr_investment inv
    WHERE     alloc.parent_transaction_id = ptxn.id
          AND ptxn.definition LIKE '%Reinvest%'
          AND ptxn.parent_transaction_id IS NULL
          AND itd.information_id = ptxn.id
          AND inv.id = h.value_id
          AND h.id = alloc.holding_id
          AND p.id = h.portfolio_id
          AND r.id = p.role_id
/
