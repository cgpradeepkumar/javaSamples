CREATE VIEW DLR_VIEW_INVESTORS AS SELECT investor.ID investor_id,
          investor.NAME investor_name,
          dlr_portfolio.ID portfolio_id,
          dlr_portfolio.NAME portfolio_name,
          dlr_holding.ID holding_id,
          dlr_holding.HOLDING_NAME,
          supplier.ID investment_supplier_id,
          supplier.NAME investment_supplier_orbit_name,
          supplier.DESCRIPTION investment_supplier_name,
          dlr_investment.ID investment_id,
          dlr_value.VALUE_NAME investment_name,
          dlr_investment.EXTERNAL_REFERENCE investment_orbit_name,
          ps.strategy_name product_strategy_name
     FROM dlr_holding,
          dlr_portfolio,
          dlr_investor_portfolio,
          dlr_role investor,
          dlr_role supplier,
          dlr_value,
          dlr_investment,
          dlr_product_strategy ps
    WHERE     dlr_investment.ID = dlr_holding.VALUE_ID
          AND dlr_value.ID = dlr_investment.ID
          AND ps.id = dlr_investor_portfolio.product_strategy_id
          AND supplier.ID = dlr_investment.INVESTMENT_SUPPLIER_ID
          AND dlr_investor_portfolio.ID = dlr_holding.PORTFOLIO_ID
          AND dlr_portfolio.ID = dlr_investor_portfolio.ID
          AND investor.ID = dlr_portfolio.ROLE_ID
/
