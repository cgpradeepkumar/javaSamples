CREATE VIEW VW_MTAX_SCHEME_PROD_TYPE_PROB AS SELECT "ID",
            "FUND_NAME",
            "PRODUCT_TYPE",
            "CREATE_REASON",
            "APPROVAL_NUMBER",
            "PAYE_NUMBER",
            "PRIVATE",
            "ORBIT_CONTRACT",
            "ACTIVE",
            "ACTIVE_REASON"
       FROM (SELECT *
               FROM MTAX_SCHEME
              WHERE     UPPER (FUND_NAME) LIKE '%PENSION%'
                    AND PRODUCT_TYPE NOT IN (SELECT ID
                                               FROM MTAX_PRODUCT_TYPE
                                              WHERE UPPER (DESCRIPTION) LIKE
                                                       '%PENSION%')
                    AND ACTIVE = 1
             UNION
             SELECT *
               FROM MTAX_SCHEME
              WHERE     UPPER (FUND_NAME) LIKE '%PROVIDENT%'
                    AND PRODUCT_TYPE NOT IN (SELECT ID
                                               FROM MTAX_PRODUCT_TYPE
                                              WHERE UPPER (DESCRIPTION) LIKE
                                                       '%PROVIDENT%')
                    AND ACTIVE = 1) INC
   ORDER BY INC.PRODUCT_TYPE
/
