CREATE VIEW DLR_UDI_VIEW AS SELECT ptxn.id txn_id,
            r.name conno,
            p.name grpno,
            inv.external_reference porno,
            ptxn.effective_date,
            alloc.currency_quantity rands,
            ps.strategy_name,
            itd.is_distributed,
            itd.date_distributed,
            h.id holding_id
       FROM dlr_dlr_transaction alloc,
            dlr_dlr_transaction ptxn,
            dlr_investment inv,
            dlr_holding h,
            dlr_portfolio p,
            dlr_role r,
            dlr_information_to_distribute itd,
            dlr_product_strategy ps,
            dlr_investor_portfolio ip
      WHERE     alloc.parent_transaction_id = ptxn.id
            AND ptxn.definition LIKE '%UndeclaredIncome%'
            AND ptxn.state = 'Finalised'
            AND ptxn.parent_transaction_id IS NULL
            AND inv.id = h.value_id
            AND h.id = alloc.holding_id
            AND p.id = h.portfolio_id
            AND r.id = p.role_id
            AND ps.id = ip.product_strategy_id
            AND ip.id = p.id
            AND alloc.currency_quantity != 0
            AND itd.information_id = ptxn.id
   ORDER BY r.name,
            p.name,
            ptxn.effective_date,
            inv.external_reference
/
