CREATE VIEW VW_SYNC_NOT_IN_OLD_FUND AS SELECT N."FUND_ID",
          N."QCSJ_C000000000400000",
          N."FUND_TYPE_CDE",
          N."FUND_CREATE_REASON_CDE",
          N."FUND_POST_ADDRESS_ID",
          N."CONTRACT_NUMBER",
          N."FUND_NUMBER",
          N."FUND_NAME",
          N."FUND_DIAL_CODE",
          N."FUND_TEL_NO",
          N."FUND_CONTACT_PERSON",
          N."PRIVATE",
          N."ORBIT",
          N."QCSJ_C000000000400002",
          N."QCSJ_C000000000400001",
          N."CONTACT_ADDRESS_ID",
          N."CREATOR_NAME",
          N."FUND_PAYE_NO",
          N."CONTACT_PERSON_NAME",
          N."CONTACT_NUMBER_TELEPHONE",
          N."ALTERNATIVE_CONTACT_NUMBER",
          N."DIPLOMATIC_INDEMNITY",
          N."QCSJ_C000000000400003",
          N."ALIAS_NAME",
          N."EMP_TRADE_CLASSIFICATION_CDE"
     FROM (SELECT *
             FROM MTD_FUND F
                  INNER JOIN MTD_FUND_GROUP FG
                     ON F.FUND_GROUP_ID = FG.FUND_GROUP_ID) N
          LEFT JOIN
          (SELECT S.ID,
                  UPPER (TRIM (S.FUND_NAME)) AS FUND_NAME,
                  S.PRODUCT_TYPE,
                  S.CREATE_REASON,
                  S.APPROVAL_NUMBER,
                  S.PAYE_NUMBER,
                  S.PRIVATE,
                  S.ORBIT_CONTRACT,
                  S.ACTIVE,
                  S.ACTIVE_REASON
             FROM MTAX_SCHEME S
           UNION
           SELECT S.ID,
                  UPPER (TRIM (S.FUND_NAME)) AS FUND_NAME,
                  S.PRODUCT_TYPE,
                  S.CREATE_REASON,
                  S.APPROVAL_NUMBER,
                  C.PAYE_NUMBER,
                  S.PRIVATE,
                  S.ORBIT_CONTRACT,
                  S.ACTIVE,
                  S.ACTIVE_REASON
             FROM MTAX_SCHEME S
                  INNER JOIN (SELECT * FROM VW_MTAX_CERT_PAYE_PROB) C
                     ON S.ID = C.CONTRACT_NUMBER) O
             ON     N.CONTRACT_NUMBER = O.ID
                AND N.FUND_NUMBER = O.APPROVAL_NUMBER
                AND N.FUND_PAYE_NO = O.PAYE_NUMBER
    WHERE     O.ID IS NULL
          AND O.APPROVAL_NUMBER IS NULL
          AND O.PAYE_NUMBER IS NULL
/
