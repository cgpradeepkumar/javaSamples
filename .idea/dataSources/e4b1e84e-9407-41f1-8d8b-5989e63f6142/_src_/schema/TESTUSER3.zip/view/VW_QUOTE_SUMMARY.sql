CREATE VIEW VW_QUOTE_SUMMARY AS SELECT M.QUOTE_ID,
          M.QUOTE_VERSION,
          L.PRODUCT_DESC,
          BT.BEN_TYPES,
          BASIS_COUNT,
          CATEGORY_COUNT,
          MEMBER_COUNT,
             '		{new TestQuote('
          || M.QUOTE_ID
          || ', '
          || M.QUOTE_VERSION
          || ', "'
          || L.PRODUCT_DESC
          || ' ['
          || BEN_TYPES
          || '] '
          || BASIS_COUNT
          || ' Bases, '
          || CATEGORY_COUNT
          || '('
          || ROUND (CATEGORY_COUNT_TOTAL / BENEFIT_COUNT, 2)
          || ') Categories, '
          || MEMBER_COUNT
          || ' Members ", <expectedExecutionTimeInSeconds>)},'
             JAVA_CODE
     FROM Q_QUOTE_MAIN M
          INNER JOIN
          (SELECT ID,
                  DECODE (ID,
                          0, 'FAW UMB',
                          1, 'SAGE UMB',
                          2, 'Standalone - Non Sage',
                          3, 'RO Conversion',
                          4, 'Standalone - Sage',
                          5, 'RO Conversion - Sage',
                          6, 'FAW RO',
                          8, 'LEK Standalone',
                          9, 'LEK Bridging Fund UMB',
                          10, 'LEK PPWAWU UMB',
                          11, 'MCB RO',
                          12, 'FAW Standalone',
                          13, 'FAW UMB Namibia',
                          14, 'FAW RO Namibia',
                          15, 'MET RO Migration',
                          'NOT FOUND IN DB')
                     PRODUCT_DESC
             FROM Q_LOOKUP_GENERAL
            WHERE LOOKUP_TYPE = 124) L
             ON M.PRODUCT_CODE = L.ID
          INNER JOIN
          (  SELECT QUOTE_ID,
                    QUOTE_VERSION,
                    COUNT (DISTINCT BASIS_ID) BASIS_COUNT
               FROM Q_QUOTE_BASIS
           GROUP BY QUOTE_ID, QUOTE_VERSION) B
             ON M.QUOTE_ID = B.QUOTE_ID AND M.QUOTE_VERSION = B.QUOTE_VERSION
          INNER JOIN
          (  SELECT QUOTE_ID, QUOTE_VERSION, COUNT (BENEFIT_ID) BENEFIT_COUNT
               FROM Q_QUOTE_BENEFIT
           GROUP BY QUOTE_ID, QUOTE_VERSION) BEN
             ON     M.QUOTE_ID = BEN.QUOTE_ID
                AND M.QUOTE_VERSION = BEN.QUOTE_VERSION
          INNER JOIN
          (  SELECT QUOTE_ID,
                    QUOTE_VERSION,
                    COUNT (DISTINCT CATEGORY_ID) CATEGORY_COUNT
               FROM Q_QUOTE_CATEGORY
           GROUP BY QUOTE_ID, QUOTE_VERSION) C
             ON M.QUOTE_ID = C.QUOTE_ID AND M.QUOTE_VERSION = C.QUOTE_VERSION
          INNER JOIN
          (  SELECT QUOTE_ID,
                    QUOTE_VERSION,
                    COUNT (CATEGORY_ID) CATEGORY_COUNT_TOTAL
               FROM Q_QUOTE_CATEGORY
           GROUP BY QUOTE_ID, QUOTE_VERSION) CTOTAL
             ON     M.QUOTE_ID = CTOTAL.QUOTE_ID
                AND M.QUOTE_VERSION = CTOTAL.QUOTE_VERSION
          INNER JOIN
          (  SELECT QUOTE_ID,
                    QUOTE_VERSION,
                    COUNT (DISTINCT ROW_NUM) MEMBER_COUNT
               FROM Q_QUOTE_MEMBER
           GROUP BY QUOTE_ID, QUOTE_VERSION) MEM
             ON     M.QUOTE_ID = MEM.QUOTE_ID
                AND M.QUOTE_VERSION = MEM.QUOTE_VERSION
          INNER JOIN
          (  SELECT DISTINCT
                    Mi.QUOTE_ID,
                    Mi.QUOTE_VERSION,
                    stragg (DISTINCT UPPER (PB.SUB_TYPE)) BEN_TYPES
               FROM Q_QUOTE_MAIN Mi
                    INNER JOIN Q_QUOTE_BENEFIT B
                       ON     Mi.QUOTE_ID = B.QUOTE_ID
                          AND Mi.QUOTE_VERSION = B.QUOTE_VERSION
                    INNER JOIN VW_PRODUCT_BENEFIT PB
                       ON     Mi.PRODUCT_CODE = PB.PRODUCT_ID
                          AND B.BENEFIT_ID = PB.BENEFIT_ID
           GROUP BY Mi.QUOTE_ID, Mi.QUOTE_VERSION) BT
             ON     M.QUOTE_ID = BT.QUOTE_ID
                AND M.QUOTE_VERSION = BT.QUOTE_VERSION
/
