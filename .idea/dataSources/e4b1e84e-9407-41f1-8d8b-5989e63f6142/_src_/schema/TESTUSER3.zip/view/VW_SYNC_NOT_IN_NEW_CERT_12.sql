CREATE VIEW VW_SYNC_NOT_IN_NEW_CERT_12 AS SELECT O."NEW_DIRECTIVE_ID",
          O."CERTIFICATE_REF_NO",
          O."TAX_YEAR",
          O."PAYE_NUMBER"
     FROM (SELECT DISTINCT NEW_DIRECTIVE_ID,
                           CERTIFICATE_REF_NO,
                           TO_NUMBER (TAX_YEAR) AS TAX_YEAR,
                           PAYE_NUMBER
             FROM MTAX_CERTIFICATE
            WHERE TAX_CERT_TYPE IN (1, 2)) O
          LEFT JOIN
          (SELECT DISTINCT C.DIRECTIVE_NUMBER,
                           C.CERTIFICATE_NUMBER,
                           C.TAX_YEAR,
                           FG.FUND_PAYE_NO
             FROM MTD_CERTIFICATE C
                  INNER JOIN MTD_FUND F ON C.FUND_ID = F.FUND_ID
                  INNER JOIN MTD_FUND_GROUP FG
                     ON F.FUND_GROUP_ID = FG.FUND_GROUP_ID
            WHERE CERTIFICATE_TYPE_CDE IN (1, 2)) N
             ON     N.DIRECTIVE_NUMBER = O.NEW_DIRECTIVE_ID
                AND N.CERTIFICATE_NUMBER = O.CERTIFICATE_REF_NO
                AND N.TAX_YEAR = TO_NUMBER (O.TAX_YEAR)
                AND N.FUND_PAYE_NO = O.PAYE_NUMBER
    WHERE     N.DIRECTIVE_NUMBER IS NULL
          AND N.CERTIFICATE_NUMBER IS NULL
          AND N.TAX_YEAR IS NULL
          AND N.FUND_PAYE_NO IS NULL
/
