CREATE VIEW VW_SYNC_IN_ITAREA AS SELECT N."IT_AREA_ID",
          N."POST_ADDRESS_ID",
          N."RES_ADDRESS_ID",
          N."IT_AREA",
          N."NAME",
          N."DIAL_CODE",
          N."TEL_NUMBER",
          N."FAX_NUMBER",
          N."ACTIVE"
     FROM MTD_IT_AREA N
          INNER JOIN MTAX_RECEIVER_OFFICE O ON O.CODE = N.IT_AREA
/
