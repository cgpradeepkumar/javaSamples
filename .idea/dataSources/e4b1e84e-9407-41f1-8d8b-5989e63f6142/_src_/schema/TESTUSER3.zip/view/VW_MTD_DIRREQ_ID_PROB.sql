CREATE VIEW VW_MTD_DIRREQ_ID_PROB AS SELECT "DIRECTIVE_REQUEST_ID",
          "DIRECTIVE_REQUEST_TYPE_CDE",
          "DIRECTIVE_REQUEST_STATUS_CDE",
          "USER_ID",
          "FUND_ID",
          "NO_IT_REF_REASON_CDE",
          "TP_RES_ADDRESS_ID",
          "TP_POST_ADDRESS_ID",
          "TP_POSTAL_SAME_AS_RES",
          "DIR_REASON_CDE",
          "EMP_PHY_ADDRESS_ID",
          "EMP_POST_ADDRESS_ID",
          "EMP_POSTAL_SAME_AS_RES",
          "CALC_PERIOD_METHOD_CDE",
          "TRANSFER_FUND_ID",
          "GROUP_ID",
          "JPA_VERSION_NUMBER",
          "CREATED",
          "UPDATED",
          "REQ_SEQ_NUM",
          "IT_REF_NO",
          "NO_IT_REF_REASON_TEXT",
          "TP_ID",
          "TP_OTHER_ID",
          "TP_MEMBER_NO",
          "TP_EMPLOYEE_NO",
          "TP_POLICY_NO",
          "TP_DOB",
          "TP_SURNAME",
          "TP_INITS",
          "TP_FIRSTNAMES",
          "TAX_YEAR",
          "DATE_OF_ACCRUAL",
          "GROSS_LUMP_SUM",
          "LUMP_SUM_ACCRUAL_DATE",
          "FULL_RA_VALUE",
          "GROSS_AMOUNT_TOTAL_BENEFIT",
          "DIVORCE_SPOUSE_AMOUNT",
          "POLICY_DATE_START",
          "MEMBER_OWN_CONTRIB",
          "MEMBER_CONTRIB",
          "MEMBER_EXCESS_PENSION_CONTRIB",
          "CONTRIB_TO_PREV_PROV_FUND",
          "BENEFIT_CALCULATED_INDICATOR",
          "DATE_JOIN",
          "BENEFIT_CALC_START_DATE",
          "PREVIOUS_START_DATE",
          "BENEFIT_CALC_END_DATE",
          "PREVIOUS_END_DATE",
          "EMPLOYMENT_START_DATE",
          "EMPLOYMENT_END_DATE",
          "PURCH_TRANSF_ANNUITY_INDICATOR",
          "PURCH_TRANSF_ANNUITY_AMOUNT",
          "NAME_REGISTERED_INSURER",
          "ANNUITY_POLICY_NO",
          "FUND_PAYING_ANNUITY_INDICATOR",
          "REMAINING_ANNUITY_AMOUNT",
          "TP_ANNUAL_INCOME",
          "SALARY_12_MTHS_PRECEDING",
          "PAYE_REF_NO",
          "EMP_NAME",
          "EMP_DIAL_CODE",
          "EMP_TEL_NO",
          "EMP_CONTACT_PERSON",
          "XFER_TO_FUND",
          "TRANSFER_AMOUNT",
          "ONE_THIRD_COMMUTE",
          "DATE_DEATH",
          "OWN_CONTRIBUTION",
          "MEMBERS_EXCESS_CONTRIBUTION",
          "SURRENDER_VALUE",
          "PAPER_RESP",
          "PUBLIC_SECTOR_FUND_DATE_FROM",
          "PUBLIC_SECTOR_FUND_DATE_TO",
          "AMOUNT_PUBLIC_SECTOR_FUND",
          "DATE_AMT_TRANSF_PUB_SEC_FUND",
          "UNCLAIMED_BENEF_PREV_TAXED",
          "TAXED_TRANSF_NONMEM_SPOUSE",
          "BENEFIT_PAYABLE_TO",
          "BENEFIT_COMMUTED_BEFORE",
          "CANCELATION_REASON_DESC",
          "DATE_DIVORCE_ORDER",
          "LOCKED",
          "LOCKED_USER_ID",
          "CREATE_MODE_CDE",
          "COPIED_DIRECTIVE_REQUEST_ID"
     FROM MTD_DIRECTIVE_REQUEST
    WHERE    TRIM (TP_OTHER_ID) = ''
          OR TRIM (TP_OTHER_ID) = '0'
          OR TRIM (TP_OTHER_ID) = '00'
          OR TRIM (TP_OTHER_ID) = '000'
          OR TRIM (TP_OTHER_ID) = '0000'
          OR TRIM (TP_OTHER_ID) = '00000'
          OR TRIM (TP_OTHER_ID) = '000000'
          OR TRIM (TP_OTHER_ID) = '0000000'
          OR TRIM (TP_OTHER_ID) = '00000000'
          OR TRIM (TP_OTHER_ID) = '000000000'
          OR TRIM (TP_OTHER_ID) = '0000000000'
          OR TRIM (TP_OTHER_ID) = '00000000000'
          OR TRIM (TP_OTHER_ID) = '000000000000'
          OR TRIM (TP_OTHER_ID) = '0000000000000'
          OR TRIM (TP_OTHER_ID) = '00000000000000'
          OR TRIM (TP_OTHER_ID) = '000000000000000'
          OR TRIM (TP_ID) = ''
          OR TRIM (TP_ID) = '0'
          OR TRIM (TP_ID) = '00'
          OR TRIM (TP_ID) = '000'
          OR TRIM (TP_ID) = '0000'
          OR TRIM (TP_ID) = '00000'
          OR TRIM (TP_ID) = '000000'
          OR TRIM (TP_ID) = '0000000'
          OR TRIM (TP_ID) = '00000000'
          OR TRIM (TP_ID) = '000000000'
          OR TRIM (TP_ID) = '0000000000'
          OR TRIM (TP_ID) = '00000000000'
          OR TRIM (TP_ID) = '000000000000'
          OR TRIM (TP_ID) = '0000000000000'
          OR TRIM (TP_ID) = '00000000000000'
          OR TRIM (TP_ID) = '000000000000000'
/
