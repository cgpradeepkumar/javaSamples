CREATE VIEW DLR_INVESTOR_SETTLEMENT_VIEW2 AS SELECT
i.id settlement_id,
i.id ref_on_bank,
unit_txn.id dlr_txn_ref,
i.PROCESSED_DATE settlement_date,
i.effective_date,
i.state instruction_state,
si.settle_service,
ROUND (si.TOTAL_AMOUNT_QUANTITY, 2) si_amount_total,
ROUND (se.AMOUNT_QUANTITY, 2) se_amount,
ROUND (se.AMOUNT_QUANTITY, 2) bank_amount_total,
ROUND (unit_txn.currency_quantity, 2) unit_txn_rand_amount,
si.us_settle_party_id,
us.account_number dlr_account_nr,
them.account_number them_account_nr,
null definition,
null them_name,
unit_txn.definition unit_txn_definition,
unit_txn.id unit_txn_id,
unit_txn.holding_id unit_txn_holding_id,
unit_txn.denomination_id,
them.reference reference
FROM dlr_instruction i,
dlr_settlement_instruction si,
dlr_settlement_element se,
DLR_SETTLEMENT_PARTY_DETAIL us,
DLR_SETTLEMENT_PARTY_DETAIL them,
dlr_dlr_transaction unit_txn
WHERE i.id = si.id and si.id = unit_txn.settlement_id
AND se.instruction_id = si.id
AND us.id = si.us_settle_party_id
AND se.them_settle_party_id = them.id
UNION
SELECT
NULL settlement_id,
NULL REF_ON_BANK,
alloc.id DLR_TXN_REF,
ptxn.EFFECTIVE_DATE EFFECTIVE_DATE,
NULL settlement_date,
'Unknown' instruction_state,
DECODE (ptxn.SETTLEMENT_METHOD, 'None', 'RECEIPT', ptxn.SETTLEMENT_METHOD) SETTLEMENT_METHOD,
ROUND (alloc.currency_quantity, 2) SI_AMOUNT_TOTAL,
ROUND (alloc.currency_quantity, 2) SE_AMOUNT,
ROUND (alloc.currency_quantity, 2) BANK_AMOUNT_TOTAL,
ROUND (alloc.currency_quantity, 2) UNIT_TXN_RAND_AMOUNT,
NULL US_SETTLE_PARTY_ID,
NULL DLR_ACCOUNT_NR,
NULL THEM_ACCOUNT_NR,
ptxn.DEFINITION DEFINITION,
party.name THEM_NAME,
alloc.DEFINITION UNIT_TXN_DEFINITION,
alloc.id UNIT_TXN_ID,
h.id UNIT_TXN_HOLDING_ID,
alloc.DENOMINATION_ID DENOMINATION_ID,
party.name REFERENCE
FROM dlr_party party,
dlr_role r,
dlr_portfolio p,
dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
DLR_PRODUCT_STRATEGY ps,
DLR_INVESTOR_PORTFOLIO ip,
dlr_holding h,
DLR_INVESTMENT inv
WHERE alloc.PARENT_TRANSACTION_ID = ptxn.id
AND h.id = alloc.HOLDING_ID
AND p.id = h.PORTFOLIO_ID
AND r.id = p.ROLE_ID
AND party.id = r.PARTY_ID
AND ip.id = p.id
AND inv.id = h.VALUE_ID
AND ps.id = ip.PRODUCT_STRATEGY_ID
AND ps.INVESTOR_SETTLES_AM = 1
AND ptxn.SETTLEMENT_METHOD = 'None'
AND ( alloc.TRADE_STATE = 'Traded' OR alloc.DEFINITION LIKE '%Reversal%')
/
