CREATE VIEW DLR_INVESTORS_TXN_VIEW2 AS SELECT ptxn.effective_date effective_date,
          alloc.definition definition,
          alloc.processed_date processed_date,
          alloc.id txn_id,
          ptxn.EXTERNAL_REFERENCE tradeno,
          alloc.holding_id holding_id,
          ROUND (alloc.currency_quantity, 2) rands,
          ROUND (
             DECODE (alloc.direction,
                     '-', -1 * alloc.unit_quantity2,
                     alloc.unit_quantity2),
             6)
             units,
          inv.id investment_id,
          investors.INVESTOR_NAME conno,
          investors.PORTFOLIO_NAME grpno,
          inv.external_reference porno
     FROM dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_holding h,
          dlr_investment inv,
          dlr_view_investors investors
    WHERE     alloc.parent_transaction_id = ptxn.id
          AND ptxn.state = 'Finalised'
          AND alloc.definition LIKE '%Allocation'
          AND h.id = alloc.holding_id
          AND h.id = investors.holding_id
          AND inv.id = h.value_id
   UNION
   SELECT ptxn.effective_date effective_date,
          alloc.definition definition,
          alloc.processed_date processed_date,
          alloc.id txn_id,
          ptxn.EXTERNAL_REFERENCE tradeno,
          alloc.holding_id holding_id,
          ROUND (alloc.currency_quantity, 2) rands,
          ROUND (
             DECODE (alloc.direction,
                     '-', -1 * alloc.unit_quantity2,
                     alloc.unit_quantity2),
             6)
             units,
          inv.id investment_id,
          investors.INVESTOR_NAME conno,
          investors.PORTFOLIO_NAME grpno,
          inv.external_reference porno
     FROM dlr_dlr_transaction pptxn,
          dlr_dlr_transaction ptxn,
          dlr_dlr_transaction alloc,
          dlr_dlr_transaction contra,
          dlr_holding h,
          dlr_investment inv,
          dlr_view_investors investors
    WHERE     alloc.parent_transaction_id = pptxn.id
          AND pptxn.parent_transaction_id = ptxn.id
          AND contra.parent_transaction_id = alloc.id
          AND ptxn.state = 'Finalised'
          AND alloc.definition LIKE '%Allocation'
          AND h.id = alloc.holding_id
          AND h.id = investors.holding_id
          AND inv.id = h.value_id
/
