CREATE VIEW VW_MTAX_GROUP_DIR_CER_IT3_PROB AS SELECT TMP.GROUP_CODE, TMP.GROUP_NAME, TMP1.cnt
       FROM (  SELECT UPPER (GROUP_NAME) AS GROUP_NAME,
                      UPPER (GROUP_CODE) AS GROUP_CODE
                 FROM MTAX_DIRECTIVE
             GROUP BY UPPER (GROUP_NAME), UPPER (GROUP_CODE)
             UNION
               SELECT UPPER (GROUP_NAME), UPPER (GROUP_NUMBER) AS GROUP_CODE
                 FROM MTAX_CERTIFICATE
             GROUP BY UPPER (GROUP_NAME), UPPER (GROUP_NUMBER)
             UNION
               SELECT UPPER (GROUPNAME) AS GROUP_NAME,
                      UPPER (GROUPNUMBER) AS GROUP_CODE
                 FROM MTAX_IT3A
             GROUP BY UPPER (GROUPNAME), UPPER (GROUPNUMBER)) TMP
            INNER JOIN
            (  SELECT DUP.GROUP_CODE, SUM (CNT) AS CNT
                 FROM (  SELECT UPPER (GROUP_CODE) AS GROUP_CODE,
                                UPPER (GROUP_NAME) AS GROUP_NAME,
                                COUNT (DISTINCT GROUP_NAME) AS CNT
                           FROM MTAX_DIRECTIVE
                       GROUP BY UPPER (GROUP_CODE), UPPER (GROUP_NAME)
                       UNION
                         SELECT UPPER (GROUP_NUMBER) AS GROUP_CODE,
                                UPPER (GROUP_NAME),
                                COUNT (DISTINCT GROUP_NAME) AS CNT
                           FROM MTAX_CERTIFICATE
                       GROUP BY UPPER (GROUP_NUMBER), UPPER (GROUP_NAME)
                       UNION
                         SELECT UPPER (GROUPNUMBER) AS GROUP_CODE,
                                UPPER (GROUPNAME) AS GROUP_NAME,
                                COUNT (DISTINCT GROUPNAME) AS CNT
                           FROM MTAX_IT3A
                       GROUP BY UPPER (GROUPNUMBER), UPPER (GROUPNAME)) DUP
             GROUP BY GROUP_CODE) TMP1
               ON TMP.GROUP_CODE = TMP1.GROUP_CODE
      WHERE TMP1.cnt > 1
   ORDER BY TMP1.cnt DESC, TMP.GROUP_CODE, TMP.GROUP_NAME
/
