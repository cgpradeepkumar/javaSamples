CREATE VIEW DLR_VIEW_PRICES AS SELECT dlr_role.ID investment_supplier_id,
            dlr_role.NAME investment_supplier_orbit_name,
            dlr_role.DESCRIPTION investment_supplier_name,
            dlr_investment.ID investment_id,
            dlr_investment.EXTERNAL_REFERENCE investment_orbit_id,
            dlr_investment.INVESTMENT_TYPE investment_type,
            dlr_value.VALUE_NAME investment_name,
            ibuyPrice.EFFECTIVE_DATE effective_date,
            ibuyPrice.rate buy_price,
            ibuyPrice.version buy_version,
            isellPrice.rate sell_price,
            isellPrice.version sell_version,
            iswitchPrice.rate switch_price,
            iswitchPrice.version switch_version,
            ipBuyPrice.rate published_buy_price,
            ipBuyPrice.version pBuy_version,
            ipBuyPrice.state price_state
       FROM dlr_role,
            dlr_value,
            dlr_investment,
            dlr_investment_exchange_rate ibuyPrice,
            dlr_investment_exchange_rate isellPrice,
            dlr_investment_exchange_rate iswitchPrice,
            dlr_investment_exchange_rate ipBuyPrice
      WHERE     dlr_value.id = dlr_investment.id
            AND dlr_role.id = dlr_investment.INVESTMENT_SUPPLIER_ID
            AND ibuyPrice.INVESTMENT_ID = dlr_value.id
            AND isellPrice.INVESTMENT_ID = dlr_value.id
            AND iswitchPrice.INVESTMENT_ID = dlr_value.id
            AND ipBuyPrice.INVESTMENT_ID = dlr_value.id
            AND isellPrice.EFFECTIVE_DATE = ibuyPrice.EFFECTIVE_DATE
            AND iswitchPrice.EFFECTIVE_DATE = ibuyPrice.EFFECTIVE_DATE
            AND ipBuyPrice.EFFECTIVE_DATE = ibuyPrice.EFFECTIVE_DATE
            AND ibuyPrice.EXCHANGE_RATE_TYPE = 'BUY'
            AND ibuyPrice.VERSION =
                   (SELECT MAX (subibuyPrice.VERSION)
                      FROM dlr_investment_exchange_rate subibuyPrice
                     WHERE     subiBuyPrice.INVESTMENT_ID =
                                  ibuyPrice.INVESTMENT_ID
                           AND subiBuyPrice.EFFECTIVE_DATE =
                                  ibuyPrice.EFFECTIVE_DATE
                           AND subibuyPrice.EXCHANGE_RATE_TYPE = 'BUY')
            AND isellPrice.EXCHANGE_RATE_TYPE = 'SELL'
            AND isellPrice.VERSION = ibuyPrice.VERSION
            AND iswitchPrice.EXCHANGE_RATE_TYPE = 'CRT'
            AND iswitchPrice.VERSION = ibuyPrice.VERSION
            AND ipBuyPrice.EXCHANGE_RATE_TYPE = 'PUBLISHED_BUY'
            AND ipBuyPrice.VERSION = ibuyPrice.VERSION
   ORDER BY ibuyPrice.effective_date
/
