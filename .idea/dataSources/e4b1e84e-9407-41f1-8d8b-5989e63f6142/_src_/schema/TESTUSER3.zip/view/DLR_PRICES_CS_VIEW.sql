CREATE VIEW DLR_PRICES_CS_VIEW AS select er1.rate/100 "PRICE_BUY",er2.rate/100 "PRICE_SELL",er3.rate/100 "PRICE_SWITCH",er4.rate/100 "PRICE_PUBLISHED_BUY",er1.effective_date selected_date,er1.effective_date "EFFECTIVEDATE",
inv.external_reference porno,inv.id "INVESTMENTID", ier1.USED buy_used,ier1.STATE buy_state,ier2.USED sell_used,ier2.STATE sell_state,ier3.USED switch_used,ier3.STATE switch_state,ier4.USED pub_buy_used,ier4.STATE pub_buy_state
from dlr_exchange_rate er1,dlr_investment_exchange_rate ier1,
dlr_exchange_rate er2,dlr_investment_exchange_rate ier2,
dlr_exchange_rate er3,dlr_investment_exchange_rate ier3,
dlr_exchange_rate er4,dlr_investment_exchange_rate ier4,
dlr_investment inv
where 
er1.id=ier1.id
and inv.id=er1.from_value_id
and ier1.STATE='AUTHORISED'
and ier1.exchange_rate_type='BUY'
and er2.id=ier2.id
and inv.id=er2.from_value_id
and ier2.state=ier1.state
and er2.effective_date=er1.effective_date
and ier2.exchange_rate_type='SELL'
and er3.id=ier3.id
and inv.id=er3.from_value_id
and ier3.state=ier1.state
and er3.effective_date=er1.effective_date
and ier3.exchange_rate_type='CRT'
and er4.id=ier4.id
and inv.id=er4.from_value_id
and ier4.state=ier1.state
and er4.effective_date=er1.effective_date
and ier4.exchange_rate_type='PUBLISHED_BUY'
order by er1.effective_date
/
