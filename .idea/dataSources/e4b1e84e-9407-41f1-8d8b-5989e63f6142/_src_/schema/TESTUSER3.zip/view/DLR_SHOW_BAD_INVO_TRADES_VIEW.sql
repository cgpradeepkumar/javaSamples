CREATE VIEW DLR_SHOW_BAD_INVO_TRADES_VIEW AS SELECT invo.PORTFOLIO_ID invo_portfolio_id,
          h.PORTFOLIO_ID dlr_portfolio_id,
          invo."ID",
          invo."AUTHOR",
          invo."EFFECTIVE_DATE",
          invo."UNIT_INXN_TYPE",
          invo."CURRENT_STATE_NAME",
          invo."CURRENT_STATE_DATE",
          invo."AMOUNT",
          invo."DENOMINATION",
          invo."PARTY_ID",
          invo."ROLE_ID",
          invo."PORTFOLIO_ID",
          invo."HOLDING_ID"
     FROM INVO_INSTRUCTION invo, DLR_HOLDING h
    WHERE h.id = invo.HOLDING_ID AND invo.PORTFOLIO_ID != h.PORTFOLIO_ID
/
