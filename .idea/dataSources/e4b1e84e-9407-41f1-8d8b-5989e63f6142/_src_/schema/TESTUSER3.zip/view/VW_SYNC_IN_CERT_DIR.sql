CREATE VIEW VW_SYNC_IN_CERT_DIR AS SELECT N.*
     FROM (SELECT *
             FROM MTD_CERTIFICATE C
                  INNER JOIN MTD_DIRECTIVE_RESPONSE DR
                     ON C.DIRECTIVE_RESPONSE_ID = DR.DIRECTIVE_RESPONSE_ID
                  INNER JOIN MTD_DIRECTIVE_REQUEST D
                     ON DR.DIRECTIVE_REQUEST_ID = D.DIRECTIVE_REQUEST_ID) N
          INNER JOIN
          (SELECT *
             FROM (SELECT *
                     FROM (SELECT DISTINCT NEW_DIRECTIVE_ID,
                                           CERTIFICATE_REF_NO,
                                           TO_NUMBER (TAX_YEAR) AS TAX_YEAR,
                                           PAYE_NUMBER
                             FROM MTAX_CERTIFICATE
                            WHERE     TAX_CERT_TYPE IN (1, 2)
                                  AND DIR_ID_NUMERIC = 1)) C
                  INNER JOIN VW_MTAX_OLD_DIRRESP_ALL DR
                     ON C.NEW_DIRECTIVE_ID = DR.DIRECTIVE_ID
                  INNER JOIN MTAX_DIRECTIVE D
                     ON DR.REFERENCE_KEY = D.REFERENCE_KEY) O
             ON N.DIRECTIVE_NUMBER = O.DIRECTIVE_ID
/
