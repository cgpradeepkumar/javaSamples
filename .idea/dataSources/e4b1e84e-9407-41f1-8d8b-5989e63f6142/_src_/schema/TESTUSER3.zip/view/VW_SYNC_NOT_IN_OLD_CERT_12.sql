CREATE VIEW VW_SYNC_NOT_IN_OLD_CERT_12 AS SELECT N."DIRECTIVE_NUMBER",
          N."CERTIFICATE_NUMBER",
          N."TAX_YEAR",
          N."FUND_PAYE_NO"
     FROM (SELECT DISTINCT C.DIRECTIVE_NUMBER,
                           C.CERTIFICATE_NUMBER,
                           C.TAX_YEAR,
                           FG.FUND_PAYE_NO
             FROM MTD_CERTIFICATE C
                  INNER JOIN MTD_FUND F ON C.FUND_ID = F.FUND_ID
                  INNER JOIN MTD_FUND_GROUP FG
                     ON F.FUND_GROUP_ID = FG.FUND_GROUP_ID
            WHERE CERTIFICATE_TYPE_CDE IN (1, 2)) N
          LEFT JOIN (SELECT DISTINCT NEW_DIRECTIVE_ID,
                                     CERTIFICATE_REF_NO,
                                     TO_NUMBER (TAX_YEAR) AS TAX_YEAR,
                                     PAYE_NUMBER
                       FROM MTAX_CERTIFICATE
                      WHERE TAX_CERT_TYPE IN (1, 2)) O
             ON     N.DIRECTIVE_NUMBER = O.NEW_DIRECTIVE_ID
                AND N.CERTIFICATE_NUMBER = O.CERTIFICATE_REF_NO
                AND N.TAX_YEAR = TO_NUMBER (O.TAX_YEAR)
                AND N.FUND_PAYE_NO = O.PAYE_NUMBER
    WHERE     O.NEW_DIRECTIVE_ID IS NULL
          AND O.CERTIFICATE_REF_NO IS NULL
          AND O.TAX_YEAR IS NULL
          AND O.PAYE_NUMBER IS NULL
/
