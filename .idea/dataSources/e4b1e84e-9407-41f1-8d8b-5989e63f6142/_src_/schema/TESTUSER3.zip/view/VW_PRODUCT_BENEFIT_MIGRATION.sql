CREATE VIEW VW_PRODUCT_BENEFIT_MIGRATION AS SELECT "PRODUCT_ID",
          "BENEFIT_ID",
          "LOOKUP_TYPE",
          "ID",
          "TYPE_NAME",
          "ID_NAME",
          "FORMAT_TYPE",
          "PRODUCT_DESCRIPTION",
          "EXTERNAL_VALUE",
          "SEQUENCE_NO",
          "ACTIVE_INDICATOR",
          "TYPE",
          "SUB_TYPE",
          "BENEFIT_DESCRIPTION",
          "APPROVAL_TYPE",
          "CAN_BE_BUNDLED"
     FROM VW_PRODUCT_BENEFIT
    WHERE    LOWER (sub_type) LIKE '% ext'
          OR LOWER (PRODUCT_DESCRIPTION) LIKE '%migration%'
          OR LOWER (PRODUCT_DESCRIPTION) LIKE '%conversion%'
          OR LOWER (PRODUCT_DESCRIPTION) LIKE '%lekana%'
          OR LOWER (PRODUCT_DESCRIPTION) LIKE 'sage %'
          OR LOWER (PRODUCT_DESCRIPTION) LIKE '% sage%'
          OR ACTIVE_INDICATOR = 0
/
