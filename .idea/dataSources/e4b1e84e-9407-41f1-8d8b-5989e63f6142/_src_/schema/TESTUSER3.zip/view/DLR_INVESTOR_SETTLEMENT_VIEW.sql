CREATE VIEW DLR_INVESTOR_SETTLEMENT_VIEW AS SELECT
i.id settlement_id,
i.id ref_on_bank,
alloc_unit_txn.id dlr_txn_ref,
i.PROCESSED_DATE settlement_date,
i.effective_date,
i.state instruction_state,
si.settle_service,
ROUND (si.TOTAL_AMOUNT_QUANTITY,2) si_amount_total,
ROUND (si.TOTAL_AMOUNT_QUANTITY,2) se_amount,
ROUND (si.TOTAL_AMOUNT_QUANTITY,2) bank_amount_total,
ROUND (alloc_unit_txn.currency_quantity,2) unit_txn_rand_amount,
si.us_settle_party_id,
payer.account_number payer_account_number,
payee.account_number payee_account_number,
decode(payer.role_type,'InvestmentTrader',1,0) dealer_room_is_paying,
null definition,
party.name party_name,
alloc_unit_txn.definition unit_txn_definition,
alloc_unit_txn.id unit_txn_id,
alloc_unit_txn.holding_id unit_txn_holding_id,
alloc_unit_txn.denomination_id,
payee.reference reference FROM dlr_instruction i,
dlr_settlement_instruction si,
DLR_SETTLEMENT_PARTY_DETAIL payer,
DLR_SETTLEMENT_PARTY_DETAIL payee,
dlr_dlr_transaction alloc_unit_txn,
dlr_dlr_transaction ptxn,
dlr_holding h,
dlr_portfolio p,
dlr_role r,
dlr_party party,
DLR_INVESTOR_PORTFOLIO ip
WHERE i.id = si.id
and si.id = alloc_unit_txn.settlement_id
and h.id=alloc_unit_txn.HOLDING_ID
and p.id=h.PORTFOLIO_ID
and r.id=p.ROLE_ID
and party.id=r.PARTY_ID
and ip.id=p.id
and ptxn.PARENT_TRANSACTION_ID is null
and ptxn.id= alloc_unit_txn.PARENT_TRANSACTION_ID
AND payer.id = si.PAYER_ID
AND payee.ID = si.PAYEE_ID
	UNION
SELECT
NULL settlement_id,
NULL REF_ON_BANK,
alloc.id DLR_TXN_REF,
ptxn.EFFECTIVE_DATE EFFECTIVE_DATE,
NULL settlement_date,
'Unknown' instruction_state,
DECODE (ptxn.SETTLEMENT_METHOD,'None','RECEIPT',ptxn.SETTLEMENT_METHOD) SETTLEMENT_METHOD,
ROUND (alloc.currency_quantity,2) SI_AMOUNT_TOTAL,
ROUND (alloc.currency_quantity,2) SE_AMOUNT,
ROUND (alloc.currency_quantity,2) BANK_AMOUNT_TOTAL,
ROUND (alloc.currency_quantity,2) UNIT_TXN_RAND_AMOUNT,
NULL US_SETTLE_PARTY_ID,
NULL payer_ACCOUNT_NR,
NULL payee_ACCOUNT_NR,
0 dealer_room_is_paying,
ptxn.DEFINITION DEFINITION,
party.name THEM_NAME,
alloc.DEFINITION UNIT_TXN_DEFINITION,
alloc.id UNIT_TXN_ID,
h.id UNIT_TXN_HOLDING_ID,
alloc.DENOMINATION_ID DENOMINATION_ID,
party.name REFERENCE FROM dlr_party party,
dlr_role r,
dlr_portfolio p,
dlr_dlr_transaction ptxn,
dlr_dlr_transaction alloc,
DLR_PRODUCT_STRATEGY ps,
DLR_INVESTOR_PORTFOLIO ip,
dlr_holding h,
DLR_INVESTMENT inv
WHERE alloc.PARENT_TRANSACTION_ID = ptxn.id
AND h.id = alloc.HOLDING_ID
AND p.id = h.PORTFOLIO_ID
AND r.id = p.ROLE_ID
AND party.id = r.PARTY_ID
AND ip.id = p.id
AND inv.id = h.VALUE_ID
AND ps.id = ip.PRODUCT_STRATEGY_ID
AND ps.INVESTOR_SETTLES_AM = 1
AND ptxn.SETTLEMENT_METHOD = 'None'
AND ( alloc.TRADE_STATE = 'Traded' OR alloc.DEFINITION LIKE '%Reversal%')
/
