CREATE VIEW DLR_VIEW_TXN_HISTORY AS SELECT r.id roleID,
          r.name partyName,
          r.description,
          p.id portfolioid,
          p.name portfolioName,
          p.description portfolioDescription,
          inv.id investmentid,
          inv.external_reference investmentExtRef,
          h.id holdingid,
          ROUND (
             DECODE (txn.direction,
                     '-', -1 * txn.currency_quantity,
                     txn.currency_quantity),
             2)
             txnAmount,
          0.0 txnLongCost,
          0.0 txnCost,
          0.0 txnLongUnits,
          0.0 txnShortCost,
          0.0 txnShortUnits,
          0.0 txnRBOC,
          0.0 txnWAUCP,
          ROUND (
             DECODE (txn.direction,
                     '-', -1 * txn.unit_quantity2,
                     txn.unit_quantity2),
             6)
             txnUnits,
          ROUND (txn.resultant_unit_quantity, 6) txnRUB,
          (  ROUND (txn.resultant_unit_quantity, 6)
           + ROUND (
                DECODE (txn.direction,
                        '-', -1 * txn.unit_quantity2,
                        txn.unit_quantity2),
                6))
             calcRUB,
          ROUND (txnPrice.rate, 4) txnPriceRate,
          txn.price_type txnPriceType,
          TO_CHAR (parentTxn.effective_date, 'YYYY-MM-DD') txnPriceDate,
          TO_CHAR (parentTxn.effective_date, 'YYYY-MM-DD') txnEffectiveDate,
          0.0 calcProfit,
          0.0 txnProfitOrLoss,
          txn.price txnPriceID,
          txn.id txnid,
          txn.processed_date,
          txn.direction,
          txn.definition,
          txn.parent_transaction_id,
          r.role_type
     FROM dlr_dlr_transaction txn,
          dlr_dlr_transaction parentTxn,
          dlr_holding h,
          dlr_portfolio p,
          dlr_role r,
          dlr_investment inv,
          dlr_investment_exchange_rate txnPrice
    WHERE     parentTxn.id = txn.parent_transaction_id
          AND txnPrice.id = txn.price
          AND h.id = txn.holding_id
          AND p.id = h.portfolio_id
          AND r.id = p.role_id
          AND inv.id = h.value_id
          AND txn.definition LIKE '%Allocation'
   UNION
   SELECT r.id roleID,
          r.name partyName,
          r.description,
          p.id portfolioid,
          p.name portfolioName,
          p.description portfolioDescription,
          inv.id investmentid,
          inv.external_reference investmentExtRef,
          h.id holdingid,
          ROUND (
             DECODE (txn.direction,
                     '-', -1 * txn.currency_quantity,
                     txn.currency_quantity),
             4)
             txnAmount,
          0.0 txnLongCost,
          0.0 txnCost,
          0.0 txnLongUnits,
          0.0 txnShortCost,
          0.0 txnShortUnits,
          0.0 txnRBOC,
          0.0 txnWAUCP,
          ROUND (
             DECODE (txn.direction,
                     '-', -1 * txn.unit_quantity2,
                     txn.unit_quantity2),
             6)
             txnUnits,
          ROUND (txn.resultant_unit_quantity, 6) txnRUB,
          (  ROUND (txn.resultant_unit_quantity, 6)
           + ROUND (
                DECODE (txn.direction,
                        '-', -1 * txn.unit_quantity2,
                        txn.unit_quantity2),
                6))
             calcRUB,
          ROUND (txnPrice.rate, 4) txnPriceRate,
          txn.price_type txnPriceType,
          TO_CHAR (parentParentTxn.effective_date, 'YYYY-MM-DD') txnPriceDate,
          TO_CHAR (parentParentTxn.effective_date, 'YYYY-MM-DD')
             txnEffectiveDate,
          0.0 calcProfit,
          0.0 txnProfitOrLoss,
          parentTxn.price txnPriceID,
          txn.id txnid,
          parentTxn.processed_date,
          txn.direction,
          txn.definition,
          txn.parent_transaction_id,
          r.role_type
     FROM dlr_dlr_transaction txn,
          dlr_dlr_transaction parentTxn,
          dlr_dlr_transaction parentParentTxn,
          dlr_holding h,
          dlr_portfolio p,
          dlr_role r,
          dlr_investment inv,
          dlr_investment_exchange_rate txnPrice
    WHERE     parentTxn.id = txn.parent_transaction_id
          AND parentParentTxn.id = parentTxn.parent_transaction_id
          AND txnPrice.id = parentTxn.price
          AND h.id = txn.holding_id
          AND p.id = h.portfolio_id
          AND r.id = p.role_id
          AND inv.id = h.value_id
          AND txn.definition LIKE '%Contra'
   ORDER BY 9, 29, 28 ASC
/
