CREATE VIEW DLR_SUPPLIER_BANK_DETAILS AS SELECT
r.name AM,
r.DESCRIPTION,
v.value_name investment_name,
inv.id investment_id,
inv.external_reference porno,
h.external_reference sub_account,
isup.external_reference bulk_account,
b."ID",
b."BUSINESS_ID",
b."PARTY_ID",
b."BANK_DETAIL_TYPE",
b."PURPOSE",
b."BANK_NAME",
b."ACCOUNT_OWNER",
b."ACCOUNT_NUMBER",
b."BRANCH_CODE",
b."BRANCH_NAME",
b."STATE",
b."MODIFIED_BY",
b."AUTHORISED_BY" FROM dlr_party p,
dlr_role r,
DLR_INVESTMENT_SUP_PORTFOLIO isup,
dlr_portfolio por,
dlr_bank_details b,
dlr_holding h,
dlr_value v,
dlr_investment inv
WHERE por.id = isup.id
AND r.id = por.role_id
AND p.id = r.party_id
AND h.portfolio_id = p.id
AND b.id = h.BANK_DETAILS_ID
AND v.id = h.value_id
AND inv.id = v.id
/
