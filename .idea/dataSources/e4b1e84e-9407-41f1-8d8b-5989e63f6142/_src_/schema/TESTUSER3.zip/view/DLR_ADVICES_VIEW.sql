CREATE VIEW DLR_ADVICES_VIEW AS SELECT TO_CHAR (document.doc_id) || '=' || document.access_key
             web,
          oc_envelope_doc.ENVELOPE_ID,
          document.DOC_ID,
          document.ACCESS_KEY,
          document.DESCRIPTION,
          env.envelope_status_id,
          status.description status_description
     FROM document,
          oc_envelope_doc,
          oc_envelope env,
          oc_envelope_status status
    WHERE     document.DOC_ID IN (SELECT UNIQUE (ai.document_reference)
                                    FROM dlr_advice_instruction ai,
                                         dlr_instruction i
                                   WHERE i.id = ai.id)
          AND oc_envelope_doc.DOCUMENT_ID = document.DOC_ID
          AND env.envelope_id = oc_envelope_doc.envelope_id
          AND status.envelope_status_id = env.envelope_status_id
/
