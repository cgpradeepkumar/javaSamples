CREATE VIEW VW_PRODUCT_BENEFIT_NOT_USED AS SELECT "PRODUCT_ID",
          "BENEFIT_ID",
          "LOOKUP_TYPE",
          "ID",
          "TYPE_NAME",
          "ID_NAME",
          "FORMAT_TYPE",
          "PRODUCT_DESCRIPTION",
          "EXTERNAL_VALUE",
          "SEQUENCE_NO",
          "ACTIVE_INDICATOR",
          "TYPE",
          "SUB_TYPE",
          "BENEFIT_DESCRIPTION",
          "APPROVAL_TYPE",
          "CAN_BE_BUNDLED"
     FROM VW_PRODUCT_BENEFIT
    WHERE (PRODUCT_ID, BENEFIT_ID) IN (SELECT PRODUCT_ID, BENEFIT_ID
                                         FROM VW_PRODUCT_BENEFIT
                                       MINUS
                                       SELECT DISTINCT
                                              M.product_code, B.benefit_id
                                         FROM Q_QUOTE_MAIN M
                                              INNER JOIN Q_QUOTE_BENEFIT B
                                                 ON     M.QUOTE_ID =
                                                           B.QUOTE_ID
                                                    AND M.QUOTE_VERSION =
                                                           B.QUOTE_VERSION)
/
