CREATE VIEW VW_MTAX_SCHEME_ALL_PROB AS SELECT "ID",
          "FUND_NAME",
          "PRODUCT_TYPE",
          "CREATE_REASON",
          "APPROVAL_NUMBER",
          "PAYE_NUMBER",
          "PRIVATE",
          "ORBIT_CONTRACT",
          "ACTIVE",
          "ACTIVE_REASON",
          "PROBLEM"
     FROM (SELECT ID,
                  FUND_NAME,
                  PRODUCT_TYPE,
                  CREATE_REASON,
                  APPROVAL_NUMBER,
                  PAYE_NUMBER,
                  PRIVATE,
                  ORBIT_CONTRACT,
                  ACTIVE,
                  ACTIVE_REASON,
                  'SCHEME WITHOUT DIRECTIVE' AS PROBLEM
             FROM VW_MTAX_SCHEME_NO_DIRECTIVE
           UNION
           SELECT ID,
                  FUND_NAME,
                  PRODUCT_TYPE,
                  CREATE_REASON,
                  APPROVAL_NUMBER,
                  PAYE_NUMBER,
                  PRIVATE,
                  ORBIT_CONTRACT,
                  ACTIVE,
                  ACTIVE_REASON,
                  'DUPLICATE SCHEME' AS PROBLEM
             FROM VW_MTAX_SCHEME_DUPLICATES
           UNION
           SELECT ID,
                  FUND_NAME,
                  PRODUCT_TYPE,
                  CREATE_REASON,
                  APPROVAL_NUMBER,
                  PAYE_NUMBER,
                  PRIVATE,
                  ORBIT_CONTRACT,
                  ACTIVE,
                  ACTIVE_REASON,
                  'POTENTIAL DUPLICATE SCHEME' AS PROBLEM
             FROM VW_MTAX_SCHEME_DUP_INVESTIGATE
           UNION
           SELECT ID,
                  FUND_NAME,
                  PRODUCT_TYPE,
                  CREATE_REASON,
                  APPROVAL_NUMBER,
                  PAYE_NUMBER,
                  PRIVATE,
                  ORBIT_CONTRACT,
                  ACTIVE,
                  ACTIVE_REASON,
                  'SCHEME WITH PROD_TYPE MISMATCH' AS PROBLEM
             FROM VW_MTAX_SCHEME_PROD_TYPE_PROB) SCHEME_PROBLEMS
/
